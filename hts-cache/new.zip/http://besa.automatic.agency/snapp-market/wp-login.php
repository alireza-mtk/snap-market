<!DOCTYPE html>
	<html dir="rtl" lang="fa-IR">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>ورود &lsaquo; قالب بسامارکت | دموی اختصاصی اسنپ مارکت &#8212; وردپرس</title>
	<link rel='dns-prefetch' href='//s.w.org' />
<link rel='stylesheet' id='dashicons-css'  href='http://besa.automatic.agency/snapp-market/wp-includes/css/dashicons.min.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-rtl-css'  href='http://besa.automatic.agency/snapp-market/wp-includes/css/buttons-rtl.min.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='forms-rtl-css'  href='http://besa.automatic.agency/snapp-market/wp-admin/css/forms-rtl.min.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-rtl-css'  href='http://besa.automatic.agency/snapp-market/wp-admin/css/l10n-rtl.min.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='login-rtl-css'  href='http://besa.automatic.agency/snapp-market/wp-admin/css/login-rtl.min.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='material-design-iconic-font-css'  href='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/css/material-design-iconic-font.css?ver=2.2.0' type='text/css' media='all' />
<link rel='stylesheet' id='besa-custom-admin-css'  href='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/css/admin/custom-admin.css?ver=1.0.0' type='text/css' media='all' />
	<meta name='robots' content='noindex,noarchive' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
	<link rel="icon" href="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/favicon-1.ico" sizes="32x32" />
<link rel="icon" href="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/favicon-1.ico" sizes="192x192" />
<link rel="apple-touch-icon" href="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/favicon-1.ico" />
<meta name="msapplication-TileImage" content="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/favicon-1.ico" />
	</head>
	<body class="login no-js login-action-login wp-core-ui rtl  locale-fa-ir">
	<script type="text/javascript">
		document.body.className = document.body.className.replace('no-js','js');
	</script>
		<div id="login">
		<h1><a href="http://wp-parsi.com">با نیروی وردپرس</a></h1>
	
		<form name="loginform" id="loginform" action="http://besa.automatic.agency/snapp-market/wp-login.php" method="post">
			<p>
				<label for="user_login">نام کاربری یا نشانی ایمیل</label>
				<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" />
			</p>

			<div class="user-pass-wrap">
				<label for="user_pass">رمز عبور</label>
				<div class="wp-pwd">
					<input type="password" name="pwd" id="user_pass" class="input password-input" value="" size="20" />
					<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="نمایش رمز">
						<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					</button>
				</div>
			</div>
						<p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> <label for="rememberme">مرا به خاطر بسپار</label></p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="ورود" />
									<input type="hidden" name="redirect_to" value="http://besa.automatic.agency/snapp-market/wp-admin/" />
									<input type="hidden" name="testcookie" value="1" />
			</p>
		</form>

					<p id="nav">
								<a href="http://besa.automatic.agency/snapp-market/my-account/lost-password/">رمز عبورتان را گم کرده‌اید؟</a>
			</p>
					<script type="text/javascript">
			function wp_attempt_focus() {setTimeout( function() {try {d = document.getElementById( "user_login" );d.focus(); d.select();} catch( er ) {}}, 200);}
wp_attempt_focus();
if ( typeof wpOnload === 'function' ) { wpOnload() }		</script>
				<p id="backtoblog"><a href="http://besa.automatic.agency/snapp-market/">
		&rarr; بازگشت به قالب بسامارکت | دموی اختصاصی اسنپ مارکت		</a></p>
			</div>
	<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/jquery.validate.js?ver=1.0' id='jquery-validate-js'></script>
<script type='text/javascript' id='besa-auth-script-js-extra'>
/* <![CDATA[ */
var besa_ajax_auth_object = {"ajaxurl":"http:\/\/besa.automatic.agency\/snapp-market\/wp-admin\/admin-ajax.php","redirecturl":"http:\/\/besa.automatic.agency\/snapp-market","loadingmessage":"\u062f\u0631 \u062d\u0627\u0644 \u0627\u0631\u0633\u0627\u0644 \u0627\u0637\u0644\u0627\u0639\u0627\u062a \u06a9\u0627\u0631\u0628\u0631\u060c \u0645\u0646\u062a\u0638\u0631 \u0628\u0645\u0627\u0646\u06cc\u062f ...","validate":{"required":"\u0627\u06cc\u0646 \u0641\u06cc\u0644\u062f \u0627\u0644\u0632\u0627\u0645\u06cc \u0627\u0633\u062a.","remote":"\u0627\u06cc\u0646 \u0641\u06cc\u0644\u062f \u0631\u0627 \u0641\u06cc\u06a9\u0633 \u06a9\u0646\u06cc\u062f.","email":"\u0622\u062f\u0631\u0633 \u0627\u06cc\u0645\u06cc\u0644 \u0645\u0639\u062a\u0628\u0631 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","url":"\u06cc\u06a9 \u0622\u062f\u0631\u0633 \u0645\u0639\u062a\u0628\u0631 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","date":"\u062a\u0627\u0631\u06cc\u062e \u0645\u0639\u062a\u0628\u0631\u06cc \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","dateISO":"\u062a\u0627\u0631\u06cc\u062e \u0645\u0639\u062a\u0628\u0631\u06cc (ISO) \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","number":"\u06cc\u06a9 \u0634\u0645\u0627\u0631\u0647 \u0645\u0639\u062a\u0628\u0631 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","digits":"\u0641\u0642\u0637 \u0639\u062f\u062f \u0648 \u0631\u0642\u0645 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","creditcard":"\u06cc\u06a9 \u0634\u0645\u0627\u0631\u0647 \u06a9\u0627\u0631\u062a \u0645\u0639\u062a\u0628\u0631 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","equalTo":"\u0645\u0642\u062f\u0627\u0631 \u06cc\u06a9\u0633\u0627\u0646\u06cc \u0631\u0627 \u0645\u062c\u062f\u062f\u0627 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","accept":"\u06cc\u06a9 \u0645\u0642\u062f\u0627\u0631 \u0628\u0627 \u067e\u0633\u0648\u0646\u062f \u0641\u0627\u06cc\u0644 \u0645\u0639\u062a\u0628\u0631 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","maxlength":"\u0628\u06cc\u0634\u062a\u0631 \u0627\u0632 {0} \u06a9\u0627\u0631\u06a9\u062a\u0631 \u0648\u0627\u0631\u062f \u0646\u06a9\u0646\u06cc\u062f.","minlength":"\u062d\u062f\u0627\u0642\u0644 {0} \u06a9\u0627\u0631\u06a9\u062a\u0631 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","rangelength":"\u0645\u0642\u062f\u0627\u0631\u06cc \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f \u06a9\u0647 \u0628\u06cc\u0646 {0} \u0648 {1} \u0637\u0648\u0644 \u062a\u0639\u062f\u0627\u062f \u06a9\u0627\u0631\u06a9\u062a\u0631\u0647\u0627\u06cc \u0622\u0646 \u0628\u0627\u0634\u062f.","range":"\u0645\u0642\u062f\u0627\u0631\u06cc \u0628\u06cc\u0646 {0} \u0648 {1} \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","max":"\u0645\u0642\u062f\u0627\u0631\u06cc \u06a9\u0648\u0686\u06a9\u062a\u0631 \u0645\u0633\u0627\u0648\u06cc {0} \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","min":"\u0645\u0642\u062f\u0627\u0631\u06cc \u0628\u0632\u0631\u06af\u062a\u0631 \u0645\u0633\u0627\u0648\u06cc {0} \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f."}};
/* ]]> */
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/ajax-auth-script.js?ver=1.0' id='besa-auth-script-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/admin/admin.min.js?ver=1.0' id='besa-admin-js'></script>
<script type='text/javascript' src='http://besa.automatic.agency/snapp-market/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp' id='jquery-core-js'></script>
<script type='text/javascript' id='zxcvbn-async-js-extra'>
/* <![CDATA[ */
var _zxcvbnSettings = {"src":"http:\/\/besa.automatic.agency\/snapp-market\/wp-includes\/js\/zxcvbn.min.js"};
/* ]]> */
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-includes/js/zxcvbn-async.min.js?ver=1.0' id='zxcvbn-async-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=7.4.4' id='wp-polyfill-js'></script>
<script type='text/javascript' id='wp-polyfill-js-after'>
( 'fetch' in window ) || document.write( '<script defer src="http://besa.automatic.agency/snapp-market/wp-includes/js/dist/vendor/wp-polyfill-fetch.min.js?ver=3.0.0"></scr' + 'ipt>' );( document.contains ) || document.write( '<script defer src="http://besa.automatic.agency/snapp-market/wp-includes/js/dist/vendor/wp-polyfill-node-contains.min.js?ver=3.42.0"></scr' + 'ipt>' );( window.DOMRect ) || document.write( '<script defer src="http://besa.automatic.agency/snapp-market/wp-includes/js/dist/vendor/wp-polyfill-dom-rect.min.js?ver=3.42.0"></scr' + 'ipt>' );( window.URL && window.URL.prototype && window.URLSearchParams ) || document.write( '<script defer src="http://besa.automatic.agency/snapp-market/wp-includes/js/dist/vendor/wp-polyfill-url.min.js?ver=3.6.4"></scr' + 'ipt>' );( window.FormData && window.FormData.prototype.keys ) || document.write( '<script defer src="http://besa.automatic.agency/snapp-market/wp-includes/js/dist/vendor/wp-polyfill-formdata.min.js?ver=3.0.12"></scr' + 'ipt>' );( Element.prototype.matches && Element.prototype.closest ) || document.write( '<script defer src="http://besa.automatic.agency/snapp-market/wp-includes/js/dist/vendor/wp-polyfill-element-closest.min.js?ver=2.0.2"></scr' + 'ipt>' );
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-includes/js/dist/i18n.min.js?ver=bb7c3c45d012206bfcd73d6a31f84d9e' id='wp-i18n-js'></script>
<script type='text/javascript' id='password-strength-meter-js-extra'>
/* <![CDATA[ */
var pwsL10n = {"unknown":"\u0642\u062f\u0631\u062a \u0631\u0645\u0632 \u0646\u0627\u0645\u0634\u062e\u0635","short":"\u0628\u0633\u06cc\u0627\u0631 \u0633\u0633\u062a","bad":"\u0633\u0633\u062a","good":"\u0645\u06cc\u0627\u0646\u0647","strong":"\u0646\u06cc\u0631\u0648\u0645\u0646\u062f","mismatch":"\u0646\u0627\u0647\u0645\u0633\u0627\u0646"};
/* ]]> */
</script>
<script type='text/javascript' id='password-strength-meter-js-translations'>
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2020-12-05 09:13:19+0000","generator":"GlotPress\/3.0.0-alpha.2","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=1; plural=0;","lang":"fa"},"%1$s is deprecated since version %2$s! Use %3$s instead. Please consider writing more inclusive code.":["%1$s \u0627\u0632 \u0646\u06af\u0627\u0631\u0634%2$s \u0645\u0646\u0633\u0648\u062e  \u0634\u062f\u0647 \u0627\u0633\u062a! \u0628\u0647 \u062c\u0627\u06cc \u0622\u0646 \u0627\u0632 %3$s \u0627\u0633\u062a\u0641\u0627\u062f\u0647 \u0646\u0645\u0627\u06cc\u06cc\u062f. \u0644\u0637\u0641\u0627\u064b \u0646\u0648\u0634\u062a\u0646 \u06a9\u062f \u0631\u0627 \u0628\u0647 \u0637\u0648\u0631 \u062c\u0627\u0645\u0639\u200c\u062a\u0631 \u062f\u0631 \u0646\u0638\u0631 \u0628\u06af\u06cc\u0631\u06cc\u062f."]}},"comment":{"reference":"wp-admin\/js\/password-strength-meter.js"}} );
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-admin/js/password-strength-meter.min.js?ver=5.5.3' id='password-strength-meter-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-includes/js/underscore.min.js?ver=1.8.3' id='underscore-js'></script>
<script type='text/javascript' id='wp-util-js-extra'>
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/snapp-market\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-includes/js/wp-util.min.js?ver=5.5.3' id='wp-util-js'></script>
<script type='text/javascript' id='user-profile-js-translations'>
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2020-12-05 09:13:19+0000","generator":"GlotPress\/3.0.0-alpha.2","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=1; plural=0;","lang":"fa"},"Your new password has not been saved.":["\u0631\u0645\u0632 \u062a\u0627\u0632\u0647\u200c\u06cc \u0634\u0645\u0627 \u0630\u062e\u06cc\u0631\u0647 \u0646\u0634\u062f."],"Hide":["\u067e\u0646\u0647\u0627\u0646\u200c\u0633\u0627\u0632\u06cc"],"Show":["\u0646\u0645\u0627\u06cc\u0634"],"Show password":["\u0646\u0645\u0627\u06cc\u0634 \u0631\u0645\u0632"],"Confirm use of weak password":["\u062a\u0627\u06cc\u06cc\u062f \u0628\u06a9\u0627\u0631\u06af\u06cc\u0631\u06cc \u0631\u0645\u0632 \u0633\u0633\u062a"],"Hide password":["\u067e\u0646\u0647\u0627\u0646 \u06a9\u0631\u062f\u0646 \u0631\u0645\u0632"]}},"comment":{"reference":"wp-admin\/js\/user-profile.js"}} );
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-admin/js/user-profile.min.js?ver=5.5.3' id='user-profile-js'></script>
	<div class="clear"></div>
	</body>
	</html>
	
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.boldgrid.com/w3-total-cache/


Served from: besa.automatic.agency @ 1399-10-02 15:10:52 by W3 Total Cache
-->