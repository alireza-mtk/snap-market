<!DOCTYPE html>
<html dir="rtl" lang="fa-IR" class="no-js">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="//gmpg.org/xfn/11" />
					<script>document.documentElement.className = document.documentElement.className + ' yes-js js_active js'</script>
			<title>برگه پیدا نشد &#8211; قالب بسامارکت | دموی اختصاصی اسنپ مارکت</title>
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="قالب بسامارکت | دموی اختصاصی اسنپ مارکت &raquo; خوراک" href="http://besa.automatic.agency/snapp-market/feed/" />
<link rel="alternate" type="application/rss+xml" title="قالب بسامارکت | دموی اختصاصی اسنپ مارکت &raquo; خوراک دیدگاه‌ها" href="http://besa.automatic.agency/snapp-market/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/besa.automatic.agency\/snapp-market\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.5.3"}};
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='dashicons-css'  href='http://besa.automatic.agency/snapp-market/wp-includes/css/dashicons.min.css?ver=5.5.3' type='text/css' media='all' />
<style id='dashicons-inline-css' type='text/css'>
[data-font="Dashicons"]:before {font-family: 'Dashicons' !important;content: attr(data-icon) !important;speak: none !important;font-weight: normal !important;font-variant: normal !important;text-transform: none !important;line-height: 1 !important;font-style: normal !important;-webkit-font-smoothing: antialiased !important;-moz-osx-font-smoothing: grayscale !important;}
</style>
<link rel='stylesheet' id='elementor-frontend-legacy-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/elementor/assets/css/frontend-legacy-rtl.min.css?ver=3.0.13' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='http://besa.automatic.agency/snapp-market/wp-content/uploads/elementor/css/custom-frontend-rtl.min.css?ver=1605910088' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-106-css'  href='http://besa.automatic.agency/snapp-market/wp-content/uploads/elementor/css/post-106.css?ver=1605906987' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-5-all-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.min.css?ver=3.0.13' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-4-shim-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.min.css?ver=3.0.13' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-rtl-css'  href='http://besa.automatic.agency/snapp-market/wp-includes/css/dist/block-library/style-rtl.min.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-vendors-style-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors-style.css?ver=3.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-rtl-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style-rtl.css?ver=3.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-selectBox-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/yith-woocommerce-wishlist/assets/css/jquery.selectBox.css?ver=1.2.0' type='text/css' media='all' />
<link rel='stylesheet' id='yith-wcwl-font-awesome-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/yith-woocommerce-wishlist/assets/css/font-awesome.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='yith-wcwl-main-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/yith-woocommerce-wishlist/assets/css/style.css?ver=3.0.16' type='text/css' media='all' />
<style id='yith-wcwl-main-inline-css' type='text/css'>
.yith-wcwl-share li a{color: #FFFFFF;}.yith-wcwl-share li a:hover{color: #FFFFFF;}.yith-wcwl-share a.facebook{background: #39599E; background-color: #39599E;}.yith-wcwl-share a.facebook:hover{background: #39599E; background-color: #39599E;}.yith-wcwl-share a.twitter{background: #45AFE2; background-color: #45AFE2;}.yith-wcwl-share a.twitter:hover{background: #39599E; background-color: #39599E;}.yith-wcwl-share a.pinterest{background: #AB2E31; background-color: #AB2E31;}.yith-wcwl-share a.pinterest:hover{background: #39599E; background-color: #39599E;}.yith-wcwl-share a.email{background: #FBB102; background-color: #FBB102;}.yith-wcwl-share a.email:hover{background: #39599E; background-color: #39599E;}.yith-wcwl-share a.whatsapp{background: #00A901; background-color: #00A901;}.yith-wcwl-share a.whatsapp:hover{background: #39599E; background-color: #39599E;}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.3' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-layout-rtl-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/woocommerce/assets/css/woocommerce-layout-rtl.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-rtl-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen-rtl.css?ver=4.7.0' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-rtl-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/woocommerce/assets/css/woocommerce-rtl.css?ver=4.7.0' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='woocommerce_prettyPhoto_css-rtl-css'  href='//besa.automatic.agency/snapp-market/wp-content/plugins/woocommerce/assets/css/prettyPhoto-rtl.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='besa-theme-fonts-css'  href='http://fonts.googleapis.com/css?family=Open%20Sans%3A400%2C600%2C700%2C800&#038;subset=latin%2Clatin-ext&#038;display=swap' type='text/css' media='all' />
<link rel='stylesheet' id='icons-style-css'  href='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/css/font-awesome.css?ver=1.1' type='text/css' media='all' />
<link rel='stylesheet' id='dokan-style-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/dokan-lite/assets/css/style.css?ver=1605901584' type='text/css' media='all' />
<link rel='stylesheet' id='dokan-fontawesome-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/dokan-lite/assets/vendors/font-awesome/font-awesome.min.css?ver=3.0.14' type='text/css' media='all' />
<link rel='stylesheet' id='dokan-rtl-style-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/dokan-lite/assets/css/rtl.css?ver=3.0.14' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/css/bootstrap.rtl.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='besa-template-css'  href='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/css/template.rtl.css?ver=1.0' type='text/css' media='all' />
<link rel='stylesheet' id='besa-style-css'  href='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/style.css?ver=1.0' type='text/css' media='all' />
<style id='besa-style-inline-css' type='text/css'>
/* Theme Options Styles *//* Custom Color (skin) *//* check main color *//*color*//*background*/.btn-theme:hover,.btn-default:hover,.woocommerce-pagination a.button:hover,.woof_container_inner_tags ul.woof_list label:hover,.widget_price_filter .price_slider_amount .button:hover,.show-view-all a:hover,.tbay-element-banner .banner-content .style-btn:hover,.tbay-element-newsletter button[type="submit"]:hover,.widget-newletter button[type="submit"]:hover,.btn-view-all:hover,.post .entry-category.type-1 a:hover,.post-list .readmore:hover,.post-grid .readmore:hover,.entry-single .entry-description a:hover,.post-password-form input[type=submit]:hover,#comments #respond .form-submit input:hover,#reviews #respond .form-submit input:hover,.wpcf7-form .form-horizontal .wpcf7-submit:hover,.woocommerce .yith-wfbt-submit-block .yith-wfbt-submit-button-remove:hover,body table.compare-list .add-to-cart td a:hover,input#ywqa-submit-question:hover,div#new-answer-header .ywqa_submit_answer:hover,.woocommerce table.wishlist_table.shop_table .product-add-to-cart .add-cart a:hover,.more_products a:hover,.tbay-pagination-load-more a:hover,.tbay-dropdown-cart .group-button p.buttons a.button:hover,.cart-dropdown .group-button p.buttons a.button:hover,.tbay-element-mini-cart .left-right .group-button p.buttons a.button:hover,.woocommerce button.button:hover,.woocommerce a.button.wc-backward:hover,.woocommerce a.woocommerce-button.view:hover,#respond input#submit:hover,.woocommerce input.button:hover,.singular-shop div.product .single_add_to_cart_button:hover,.singular-shop .tbay-modalButton:hover,#shop-now.has-buy-now .tbay-buy-now:hover,.woocommerce-grouped-product-list-item__quantity .add-cart a.button:hover,#sticky-menu-bar #sticky-custom-add-to-cart:hover,.cart_totals .wc-proceed-to-checkout a.checkout-button:hover,.coupon .box input[type=submit]:hover,.woocommerce table.shop_table.account-orders-table a.view:hover,.woocommerce table.shop_table.my_account_orders a.view:hover,.woocommerce table.shop_table.dokan-rma-order-item-table a.view:hover,.woocommerce table.shop_table.account-orders-table a.request_warranty:hover,.woocommerce table.shop_table.my_account_orders a.request_warranty:hover,.woocommerce table.shop_table.dokan-rma-order-item-table a.request_warranty:hover,.woocommerce form.login p.last .button:hover,.woocommerce form.register p.last .button:hover,.woocommerce-order-received .order-again a:hover,.woocommerce-checkout.wc-germanized .wc-gzd-order-submit button[type="submit"]:hover,.woocommerce form.checkout_coupon > p.form-row-last .button:hover,.woocommerce-checkout-payment .place-order button.button.alt:hover,#custom-register input.submit_button:hover,#custom-login input.submit_button:hover,input[type="submit"].dokan-btn:hover,.dokan-btn-theme:hover,.dokan-btn-success:hover,.dokan-dashboard .wpuf-form-add.wpuf-style ul.wpuf-form .wpuf-submit input[type=submit]:hover,.dokan-dashboard a.add_new_attribute:hover,.dokan-add-new-product-popup input#dokan-create-new-product-btn:hover,.dokan-seller-listing .store-footer > a:hover,#dokan-seller-listing-wrap ul.dokan-seller-wrap li .store-footer .dokan-follow-store-button:hover,.dokan-orders-content #dokan-order-status-form a.dokan-cancel-status:hover,.wcmp_regi_main .register .button:hover,#report_abuse_form button.submit-report-abuse:hover,#report-abuse table input[type="submit"]:hover,.vendor_sidebar .widget_wcmp_quick_info #respond input#submit:hover,#wcmp-store-conatiner .wcmp-store-locator-wrap .wcmp-store-map-pagination .vendor_sort input[type="submit"]:hover,#wcmp-store-conatiner .wcmp-store-map-filter input[type="submit"]:hover,#wcfm-main-contentainer .wcfm-membership-wrapper input[type="submit"]:hover,#wcfm-main-contentainer .wcfm_form_simple_submit_wrapper .wcfm_submit_button:hover,.wcfm_popup_wrapper .wcfm_popup_button:hover,#wcfmmp-store #reviews .add_review button:hover,.form-row input[name="apply_for_vendor_submit"]:hover,form.wcv-form .wcv-button[type="submit"]:hover,.dashboard .wcv-dashboard-navigation ~ form input[type="submit"]:hover,.shop_settings input[name="vendor_application_submit"]:hover,form[name="export_orders"] input:hover,form[name="export_orders"] ~ table.table .order-comments input.btn:hover,.wcvendors-pro-dashboard-wrapper a.button:hover,.wcvendors-pro-dashboard-wrapper .wcv-form .control-group .button:hover,.wcvendors-pro-dashboard-wrapper input#update_button:hover,.wcvendors-pro-dashboard-wrapper .wcv-search-form .wcv-button:hover,.wcv-form .control-group .control > input.wcv-button:hover:not(#clear_button),.wcv-order-header .wcv-form .control > input#clear_button:hover,table.wcvendors-table-order .wcv-shade.wcv-fade .order_note_form input[type="submit"]:hover,table.wcvendors-table-order form #tracking_number_save_button:hover,form#wcv-store-settings input#store_save_button:hover,.wcv_store_search form input[type="submit"]:hover,.wcv_vendor_search form input[type="submit"]:hover,.btn-theme:focus,.btn-default:focus,.woocommerce-pagination a.button:focus,.woof_container_inner_tags ul.woof_list label:focus,.widget_price_filter .price_slider_amount .button:focus,.show-view-all a:focus,.tbay-element-banner .banner-content .style-btn:focus,.tbay-element-newsletter button[type="submit"]:focus,.widget-newletter button[type="submit"]:focus,.btn-view-all:focus,.post .entry-category.type-1 a:focus,.post-list .readmore:focus,.post-grid .readmore:focus,.entry-single .entry-description a:focus,.post-password-form input[type=submit]:focus,#comments #respond .form-submit input:focus,#reviews #respond .form-submit input:focus,.wpcf7-form .form-horizontal .wpcf7-submit:focus,.woocommerce .yith-wfbt-submit-block .yith-wfbt-submit-button-remove:focus,body table.compare-list .add-to-cart td a:focus,input#ywqa-submit-question:focus,div#new-answer-header .ywqa_submit_answer:focus,.woocommerce table.wishlist_table.shop_table .product-add-to-cart .add-cart a:focus,.more_products a:focus,.tbay-pagination-load-more a:focus,.tbay-dropdown-cart .group-button p.buttons a.button:focus,.cart-dropdown .group-button p.buttons a.button:focus,.tbay-element-mini-cart .left-right .group-button p.buttons a.button:focus,.woocommerce button.button:focus,.woocommerce a.button.wc-backward:focus,.woocommerce a.woocommerce-button.view:focus,#respond input#submit:focus,.woocommerce input.button:focus,.singular-shop div.product .single_add_to_cart_button:focus,.singular-shop .tbay-modalButton:focus,#shop-now.has-buy-now .tbay-buy-now:focus,.woocommerce-grouped-product-list-item__quantity .add-cart a.button:focus,#sticky-menu-bar #sticky-custom-add-to-cart:focus,.cart_totals .wc-proceed-to-checkout a.checkout-button:focus,.coupon .box input[type=submit]:focus,.woocommerce table.shop_table.account-orders-table a.view:focus,.woocommerce table.shop_table.my_account_orders a.view:focus,.woocommerce table.shop_table.dokan-rma-order-item-table a.view:focus,.woocommerce table.shop_table.account-orders-table a.request_warranty:focus,.woocommerce table.shop_table.my_account_orders a.request_warranty:focus,.woocommerce table.shop_table.dokan-rma-order-item-table a.request_warranty:focus,.woocommerce form.login p.last .button:focus,.woocommerce form.register p.last .button:focus,.woocommerce-order-received .order-again a:focus,.woocommerce-checkout.wc-germanized .wc-gzd-order-submit button[type="submit"]:focus,.woocommerce form.checkout_coupon > p.form-row-last .button:focus,.woocommerce-checkout-payment .place-order button.button.alt:focus,#custom-register input.submit_button:focus,#custom-login input.submit_button:focus,input[type="submit"].dokan-btn:focus,.dokan-btn-theme:focus,.dokan-btn-success:focus,.dokan-dashboard .wpuf-form-add.wpuf-style ul.wpuf-form .wpuf-submit input[type=submit]:focus,.dokan-dashboard a.add_new_attribute:focus,.dokan-add-new-product-popup input#dokan-create-new-product-btn:focus,.dokan-seller-listing .store-footer > a:focus,#dokan-seller-listing-wrap ul.dokan-seller-wrap li .store-footer .dokan-follow-store-button:focus,.dokan-orders-content #dokan-order-status-form a.dokan-cancel-status:focus,.wcmp_regi_main .register .button:focus,#report_abuse_form button.submit-report-abuse:focus,#report-abuse table input[type="submit"]:focus,.vendor_sidebar .widget_wcmp_quick_info #respond input#submit:focus,#wcmp-store-conatiner .wcmp-store-locator-wrap .wcmp-store-map-pagination .vendor_sort input[type="submit"]:focus,#wcmp-store-conatiner .wcmp-store-map-filter input[type="submit"]:focus,#wcfm-main-contentainer .wcfm-membership-wrapper input[type="submit"]:focus,#wcfm-main-contentainer .wcfm_form_simple_submit_wrapper .wcfm_submit_button:focus,.wcfm_popup_wrapper .wcfm_popup_button:focus,#wcfmmp-store #reviews .add_review button:focus,.form-row input[name="apply_for_vendor_submit"]:focus,form.wcv-form .wcv-button[type="submit"]:focus,.dashboard .wcv-dashboard-navigation ~ form input[type="submit"]:focus,.shop_settings input[name="vendor_application_submit"]:focus,form[name="export_orders"] input:focus,form[name="export_orders"] ~ table.table .order-comments input.btn:focus,.wcvendors-pro-dashboard-wrapper a.button:focus,.wcvendors-pro-dashboard-wrapper .wcv-form .control-group .button:focus,.wcvendors-pro-dashboard-wrapper input#update_button:focus,.wcvendors-pro-dashboard-wrapper .wcv-search-form .wcv-button:focus,.wcv-form .control-group .control > input.wcv-button:focus:not(#clear_button),.wcv-order-header .wcv-form .control > input#clear_button:focus,table.wcvendors-table-order .wcv-shade.wcv-fade .order_note_form input[type="submit"]:focus,table.wcvendors-table-order form #tracking_number_save_button:focus,form#wcv-store-settings input#store_save_button:focus,.wcv_store_search form input[type="submit"]:focus,.wcv_vendor_search form input[type="submit"]:focus,.tbay-body-default .woocommerce-mini-cart__buttons > a.wc-forward.checkout:hover {background: #1867db;}#shop-now.has-buy-now .tbay-buy-now.button, #shop-now.has-buy-now .tbay-buy-now.button.disabled {background-color: #fcd537;}#shop-now.has-buy-now .tbay-buy-now.button:not(.disabled):hover, #shop-now.has-buy-now .tbay-buy-now.button:not(.disabled):focus {background: #e2bf31;}/* check main color second *//*background*/.footer-device-mobile > * a span.count, .singular-shop div.product.product-type-external .single_add_to_cart_button {background-color: #1b73f4;}.singular-shop div.product.product-type-external .single_add_to_cart_button:hover {background: #1867db;}/*Tablet*/@media (max-width: 1199px)  and (min-width: 768px) {/*color*/.tbay-search-mobile .sumo_product_cat .optWrapper .options li.opt.selected,.tbay-search-mobile .sumo_category .optWrapper .options li.opt.selected,#custom-login-wrapper .modal-content .modal-body .nav-tabs li.active a,.active-search-mobile .tbay-search-mobile .count,#tbay-mobile-menu-navbar.search-mobile-focus .tbay-search-mobile .count,.image-mains .show-mobile > div .yith-wcwl-wishlistexistsbrowse.show i,.products-list .product-block .group-buttons > div a.added,.footer-device-mobile > * a span:hover i,.footer-device-mobile > *.active a,.footer-device-mobile > *.active a i,body.woocommerce-wishlist .footer-device-mobile > .device-wishlist a,body.woocommerce-wishlist .footer-device-mobile > .device-wishlist a i {color: #1b73f4;}/*background*/.tbay-search-mobile .form-group .input-group .button-group,.active-search-mobile .tbay-search-form.tbay-search-mobile .input-group,.products-list .product-block .group-buttons > div a:hover,.topbar-device-mobile,.topbar-device-mobile .tbay-element-mini-cart a.wc-continue,.topbar-device-mobile .cart-dropdown .cart-icon .mini-cart-items {background-color: #1b73f4;}/*Border*/.tbay-search-mobile .sumo_product_cat .optWrapper .options li.opt.selected,.tbay-search-mobile .sumo_category .optWrapper .options li.opt.selected,.tbay-search-mobile .sumo_product_cat .optWrapper .options li.opt:last-child.selected,.tbay-search-mobile .sumo_category .optWrapper .options li.opt:last-child.selected,.products-list .product-block .group-buttons > div a:hover,.topbar-device-mobile .tbay-element-mini-cart a.wc-continue {border-color: #1b73f4;}}/*Mobile*/@media (max-width: 767px) {/*color*/.footer-device-mobile > * a span:hover i,.footer-device-mobile > *.active a,.footer-device-mobile > *.active a i,body.woocommerce-wishlist .footer-device-mobile > .device-wishlist a,body.woocommerce-wishlist .footer-device-mobile > .device-wishlist a i,.shop_table.cart .cart_item > span.product-subtotal.price span.woocommerce-Price-amount.amount,.shop_table.cart .cart_item > span.product-price span.woocommerce-Price-amount.amount {color: #1b73f4;}/*background*/.topbar-device-mobile .tbay-element-mini-cart a.wc-continue,.topbar-device-mobile .cart-dropdown .cart-icon .mini-cart-items,.tbay-show-cart-mobile .product-block div.add-cart a,.tbay-addon-newletter .input-group-btn input {background-color: #1b73f4;}/*Border*/.topbar-device-mobile .tbay-element-mini-cart a.wc-continue {border-color: #1b73f4;}}/*No edit code customize*/@media (max-width: 1199px)  and (min-width: 768px) {/*color*/.footer-device-mobile > * a:hover,.footer-device-mobile > *.active a,.footer-device-mobile > *.active a i , body.woocommerce-wishlist .footer-device-mobile > .device-wishlist a,body.woocommerce-wishlist .footer-device-mobile > .device-wishlist a i,.vc_tta-container .vc_tta-panel.vc_active .vc_tta-panel-title > a span,.cart_totals table .order-total .woocs_special_price_code {color: #1b73f4;}/*background*/.topbar-device-mobile .top-cart a.wc-continue,.topbar-device-mobile .cart-dropdown .cart-icon .mini-cart-items,.footer-device-mobile > * a .mini-cart-items,.tbay-addon-newletter .input-group-btn input {background-color: #1b73f4;}/*Border*/.topbar-device-mobile .top-cart a.wc-continue {border-color: #1b73f4;}}@media (max-width: 1199px) {/* Limit logo image height for mobile according to mobile header height */.mobile-logo a img {max-width: 69px;}.mobile-logo a img {}}@media screen and (max-width: 782px) {html body.admin-bar{top: -46px !important;position: relative;}}/* Custom CSS */.yith_wcwl_wishlist_footer {display: none;}body {letter-spacing: 0;}.wp-block-themepunch-revslider .revo-tbay-arrows.tparrows.tp-leftarrow:before {content: '\e605' !important;font-family: 'simple-line-icons' !important;}.wp-block-themepunch-revslider .revo-tbay-arrows.tparrows.tp-rightarrow:before {content: '\e606' !important;font-family: 'simple-line-icons' !important;}.icon-arrow-left:before {content: "\e606" !important;}.icon-arrow-right:before {content: "\e605" !important;}.tbay-breadscrumb .product-nav-icon .right-icon .product-btn-icon:before {content: "\f054" !important;font-family: 'Font Awesome 5 Pro';position: relative;top: 3px;}.tbay-breadscrumb .product-nav-icon .product-btn-icon:before {content: "\f053" !important;font-family: 'Font Awesome 5 Pro';}.wishlist-title {display: none;}.woocommerce .product span.onsale span {font-size: 12px;}@media screen and (max-width:3000px) and (min-width:1400px){.container-fluid {width: 1200px;max-width: 1200px;}}
</style>
<link rel='stylesheet' id='font-awesome-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/elementor/assets/lib/font-awesome/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<style id='font-awesome-inline-css' type='text/css'>
[data-font="FontAwesome"]:before {font-family: 'FontAwesome' !important;content: attr(data-icon) !important;speak: none !important;font-weight: normal !important;font-variant: normal !important;text-transform: none !important;line-height: 1 !important;font-style: normal !important;-webkit-font-smoothing: antialiased !important;-moz-osx-font-smoothing: grayscale !important;}
</style>
<link rel='stylesheet' id='besa-font-tbay-custom-css'  href='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/css/font-tbay-custom.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='simple-line-icons-css'  href='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/css/simple-line-icons.css?ver=2.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='linearicons-css'  href='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/css/linearicons.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='material-design-iconic-font-css'  href='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/css/material-design-iconic-font.css?ver=2.2.0' type='text/css' media='all' />
<link rel='stylesheet' id='animate-css'  href='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/css/animate.css?ver=3.5.0' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-treeview-css'  href='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/css/jquery.treeview.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/css/magnific-popup.css?ver=1.0.0' type='text/css' media='all' />
<script type="text/template" id="tmpl-variation-template">
	<div class="woocommerce-variation-description">{{{ data.variation.variation_description }}}</div>
	<div class="woocommerce-variation-price">{{{ data.variation.price_html }}}</div>
	<div class="woocommerce-variation-availability">{{{ data.variation.availability_html }}}</div>
</script>
<script type="text/template" id="tmpl-unavailable-variation-template">
	<p>با عرض پوزش، این كالا در دسترس نیست. لطفاً ترکیب دیگری را انتخاب کنید.</p>
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min.js?ver=3.0.13' id='font-awesome-4-shim-js'></script>
<script type='text/javascript' src='http://besa.automatic.agency/snapp-market/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp' id='jquery-core-js'></script>
<link rel="https://api.w.org/" href="http://besa.automatic.agency/snapp-market/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://besa.automatic.agency/snapp-market/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://besa.automatic.agency/snapp-market/wp-includes/wlwmanifest.xml" /> 
<link rel="stylesheet" href="http://besa.automatic.agency/snapp-market/wp-content/themes/besa/rtl.css" type="text/css" media="screen" /><meta name="generator" content="WordPress 5.5.3" />
<meta name="generator" content="WooCommerce 4.7.0" />
<style type="text/css" media="screen">
	@font-face {
	  font-family: "header-font";
	  src: url("http://besa.automatic.agency/snapp-market/wp-content/uploads/fonts/IRANSansWebFaNum_Bold.ttf");
	}
	@font-face {
	  font-family: "body-font";
	  src: url("http://besa.automatic.agency/snapp-market/wp-content/uploads/fonts/Iransans-fa.ttf");
	}
	@font-face {
	  font-family: "lists-font";
	  src: url("http://besa.automatic.agency/snapp-market/wp-content/uploads/fonts/Iransans-fa.ttf");
	}h1, h2, h3, h4, h5, h6, h7	{
	font-family: "header-font"!important;
	}p, em, div	{
		font-family: "body-font"!important;
	}
	li	{
		font-family: "lists-font"!important;
	}
</style><!--[if IE]><style type="text/css" media="screen"></style><![endif]-->	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><link rel="icon" href="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/favicon-1.ico" sizes="32x32" />
<link rel="icon" href="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/favicon-1.ico" sizes="192x192" />
<link rel="apple-touch-icon" href="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/favicon-1.ico" />
<meta name="msapplication-TileImage" content="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/favicon-1.ico" />
<style type="text/css" title="dynamic-css" class="options-output">body{background-color:#ffffff;}.woocommerce .woocommerce-info a.button:hover,.woocommerce .woocommerce-message a.button:hover,.woocommerce .woocommerce-error a.button:hover , .color,a:hover,a:focus,.has-after:hover,.post .entry-category.type-2 a:hover,.entry-meta-list .entry-author a:hover,.entry-meta-list .entry-category a:hover,.entry-single .entry-category a:hover,#tab-questions a.back-to-product:hover,.woocommerce form.login .lost_password a:hover,.woocommerce form.register .lost_password a:hover,.woocommerce form.register .wcfmmp_become_vendor_link a:hover,button.btn-close:hover,.widget_besa_popup_newsletter .popup-content > a:hover,.new-input + span:before,.woof_container input[type=checkbox]:not(.woof_color_term) + span:before,form.checkout input[type=radio] + span:before,form.checkout input[type=checkbox] + span:before,.woocommerce-account input[type=radio] + span:before,.woocommerce-account input[type=checkbox] + span:before,.yith-wfbt-section .yith-wfbt-item input[type=checkbox] + span:before,.woocommerce form .form-row .woocommerce-form__input + span:before,#custom-login-wrapper #cus-rememberme + span:before,.new-input + label:before,.woof_container input[type=checkbox]:not(.woof_color_term) + label:before,form.checkout input[type=radio] + label:before,form.checkout input[type=checkbox] + label:before,.woocommerce-account input[type=radio] + label:before,.woocommerce-account input[type=checkbox] + label:before,.yith-wfbt-section .yith-wfbt-item input[type=checkbox] + label:before,.woocommerce form .form-row .woocommerce-form__input + label:before,#custom-login-wrapper #cus-rememberme + label:before,.autocomplete-suggestions > div .price,.autocomplete-suggestions > div.view-all-products,#tbay-search-form-canvas .sidebar-canvas-search .sidebar-content .button-group .button-search i:hover,#tbay-search-form-canvas .sidebar-canvas-search .sidebar-content .select-category .optWrapper .options li:hover,#tbay-search-form-canvas .sidebar-canvas-search .sidebar-content .autocomplete-suggestions .autocomplete-suggestion .product-title:hover,#tbay-search-form-canvas .sidebar-content button:hover,#tbay-header .topbar-mobile .btn:hover,#tbay-header .topbar-mobile .btn:focus,.tbay-login .account-menu ul li a:hover,.tbay-login .account-menu ul li:last-child a:hover,.tbay-custom-language li:hover .select-button,.tbay-custom-language li:hover .select-button:after,.tbay-custom-language .select-button:hover:after,#tbay-footer a:hover,.tbay-footer .menu li > a:hover,.tbay-footer ul.menu li.active a,.contact-info a:hover,.copyright a,.elementor-widget-besa-nav-menu .tbay-treevertical-lv1 > .navbar-nav > li > a.selected,.elementor-widget-besa-nav-menu .tbay-treevertical-lv1 > .navbar-nav > li > a:hover,.elementor-widget-besa-nav-menu .tbay-treevertical-lv1 > .navbar-nav > li > a.selected i,.elementor-widget-besa-nav-menu .tbay-treevertical-lv1 > .navbar-nav > li > a:hover i,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav > li.active > a,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav > li:hover > a,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav > li:focus > a,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav > li.active > a .caret,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav > li:hover > a .caret,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav > li:focus > a .caret,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav > li .dropdown-menu > li.active > a,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav > li .dropdown-menu > li:hover :focus > a,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav > li.active-mega-menu .dropdown-menu ul > li.active > a,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav > li.active-mega-menu .dropdown-menu ul > li > a:hover,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav > li.active-mega-menu .dropdown-menu ul > li > a:focus,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav .dropdown-menu > li:hover > a,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav .dropdown-menu > li.active > a,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav .dropdown-menu > li:focus > a,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav .dropdown-menu > li > a:hover,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav .dropdown-menu .tbay-addon ul:not(.entry-meta-list) li > a:hover,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav .dropdown-menu .tbay-addon ul:not(.entry-meta-list) li.active a,.navbar-offcanvas .navbar-nav > li.open > a:hover,.navbar-offcanvas .navbar-nav > li.open > a:focus,.navbar-offcanvas .navbar-nav > li.open > a,.navbar-offcanvas .navbar-nav > li.active > a:hover,.navbar-offcanvas .navbar-nav > li.active > a:focus,.navbar-offcanvas .navbar-nav > li.active > a,.navbar-offcanvas .navbar-nav > li:hover > a:hover,.navbar-offcanvas .navbar-nav > li:hover > a:focus,.navbar-offcanvas .navbar-nav > li:hover > a,.navbar-offcanvas .navbar-nav > li.collapsable > a:hover,.navbar-offcanvas .navbar-nav > li.collapsable > a:focus,.navbar-offcanvas .navbar-nav > li.collapsable > a,.navbar-offcanvas .navbar-nav > li.open .hitarea:after,.navbar-offcanvas .navbar-nav > li.active .hitarea:after,.navbar-offcanvas .navbar-nav > li:hover .hitarea:after,.navbar-offcanvas .navbar-nav > li.collapsable .hitarea:after,.navbar-offcanvas .dropdown-menu > li.active > a,.navbar-offcanvas .dropdown-menu > li > a:hover,.navbar-offcanvas .dropdown-menu > li > a:focus,.tbay-treeview .navbar-nav > li.active-mega-menu .dropdown-menu ul > li > a:hover,.tbay-vertical > .navbar-nav .dropdown-menu > li > a:hover,.tbay-vertical > .navbar-nav .sub-menu > li > a:hover,.tbay-vertical > .navbar-nav .dropdown-menu .tbay-vertical > .navbar-nav > li > a:hover,.tbay-vertical > .navbar-nav .sub-menu .tbay-vertical > .navbar-nav > li > a:hover,.menu-canvas-content .tbay-vertical .navbar-nav > li:hover > a,.menu-canvas-content .tbay-vertical .navbar-nav > li:hover > a i,.menu-canvas-content .tbay-vertical .navbar-nav li > a.selected,.menu-canvas-content .tbay-vertical .navbar-nav li > a:hover,.menu-canvas-content .tbay-vertical .navbar-nav li > a.selected i,.menu-canvas-content .tbay-vertical .navbar-nav li > a.selected .caret,.menu-canvas-content .tbay-vertical .navbar-nav li > a:hover i,.menu-canvas-content .tbay-vertical .navbar-nav li > a:hover .caret,.menu-canvas-content .tbay-vertical .navbar-nav .tbay-addon-nav-menu li a:hover,.element-menu-canvas .menu-canvas-content .tbay-vertical .navbar-nav .dropdown-menu > li > a:hover,body:not(.tbay-body-default) .widget.yith-woocompare-widget a.compare:hover,body:not(.tbay-body-default) .widget_recent_entries > ul li a,body:not(.tbay-body-default) .widget_product_categories .product-categories a:hover,body:not(.tbay-body-default) .widget_product_categories ul a:hover,body:not(.tbay-body-default) .widget_categories .product-categories a:hover,body:not(.tbay-body-default) .widget_categories ul a:hover,body:not(.tbay-body-default) .widget_product_categories .product-categories .current-cat > a,body:not(.tbay-body-default) .widget_product_categories ul .current-cat > a,body:not(.tbay-body-default) .widget_categories .product-categories .current-cat > a,body:not(.tbay-body-default) .widget_categories ul .current-cat > a,.widget_besa_posts .post .comments-link a:hover,.woof_list_label li .woof_label_term.checked,ul.woof_list li .hover,ul.woof_list label.woof_radio_label_selected,ul.woof_list label:hover,ul.woof_list.woof_list_checkbox li label:hover,ul.woof_list.woof_list_checkbox li label.woof_checkbox_label_selected,.widget_besa_custom_menu ul.treeview li > a:hover,.widget_besa_list_categories .cat-name:hover,.tagcloud a:hover,ul.list-tags li a:hover,.show-all:hover,.widget_pages > ul li.current-cat a,.widget_meta > ul li.current-cat a,.widget_archive > ul li.current-cat a,.widget_pages > ul li a:hover,.widget_meta > ul li a:hover,.widget_archive > ul li a:hover,.widget_besa_popup_newsletter .popup-content > span , .wpml-ls-legacy-dropdown a:hover, .wpml-ls-legacy-dropdown a:focus, .wpml-ls-legacy-dropdown .wpml-ls-current-language:hover > a,.widget_search .btn:hover i,.tbay-breadscrumb .breadcrumb li a:hover,.tbay-breadscrumb .product-nav-icon .img-link:hover,.besa-back-btn:hover,.tbay-body-default .entry-single .tagcloud a:hover,.tbay-body-default .entry-single .tagcloud a:focus,.tbay-body-default .sidebar .tagcloud a:hover,.tbay-body-default .sidebar .tagcloud a:focus,.tbay-body-default .footer .tagcloud a:hover,.tbay-body-default .footer .tagcloud a:focus,.tbay-body-default .widget_pages > ul li a:hover,.tbay-body-default .widget_meta > ul li a:hover,.tbay-body-default .widget_archive > ul li a:hover,.tbay-body-default #tbay-footer a:hover , div[class^=wp-block-] a,figure[class^=wp-block-] a,ul[class^=wp-block-] a, .tbay-body-default .main-page a, .tbay-body-default .entry-single a , div[class^=wp-block-] a:active,figure[class^=wp-block-] a:active,ul[class^=wp-block-] a:active,.tbay-body-default .main-page a:active,div[class^=wp-block-] a:hover,figure[class^=wp-block-] a:hover,ul[class^=wp-block-] a:hover,.tbay-body-default .main-page a:hover,.product-block.v1 .group-buttons > div a.added,.product-block.v1 .group-buttons .yith-wcwl-wishlistexistsbrowse a,.product-block.v1 .group-buttons .yith-wcwl-wishlistaddedbrowse a,.product-block.v2 .yith-compare a.added,.product-block.v3 .group-buttons > div a.added,.product-block.v3 .yith-wcwl-wishlistexistsbrowse.show a,.product-block.v3 .yith-wcwl-wishlistaddedbrowse.show a,.product-block.v4 .add-cart a,.product-block.v4 .add-cart a.added + a.added_to_cart:hover,.product-block.v4 .yith-compare a.added,.product-block.v4 .yith-wcwl-wishlistexistsbrowse.show a,.product-block.v4 .yith-wcwl-wishlistaddedbrowse.show a,.product-block.v5 .add-cart a.added + a.added_to_cart,.product-block.v5 .yith-compare a.added,.product-block.v5 .tbay-product-slider-gallery .slick-arrow:hover,.product-block.v6 .yith-compare a.added,.product-block.v6 .tbay-product-slider-gallery .slick-arrow:hover,.product-block.v7 .add-cart a.added + a.added_to_cart,.product-block.v7 .yith-compare a.added,.product-block.v8 ul.show-brand a:hover,.product-block.v8 .yith-compare a.added,.product-block.v9 .tbay-product-slider-gallery .slick-arrow:hover,.product-block.v9 .group-buttons > div a.added,.product-block.v9 .add-cart a,.product-block.v9 .name a:hover,.product-block.v10 .name a:hover,.product-block.v10 .yith-compare a.added,.product-block.v11 .add-cart a,.product-block.v11 .yith-compare a.added,.product-block.v12 .add-cart a,.product-block.v12 .add-cart a.added + a.added_to_cart:hover,.product-block.v12 .yith-compare a.added,.product-block.v12 .yith-wcwl-wishlistexistsbrowse.show a,.product-block.v12 .yith-wcwl-wishlistaddedbrowse.show a,.product-block.v13 .tbay-product-slider-gallery .slick-arrow:hover,.product-block.v13 .yith-compare a.added,.product-block.v15 .tbay-product-slider-gallery .slick-arrow:hover,.product-block.v15 .group-buttons > div a.added,.product-block.v15 .name a:hover,.product-block.v16 .button-wishlist a:hover,.product-block.v16 .group-buttons > div a:hover,.product-block.v16 .group-buttons > div a.added,.product-block.v16 .tbay-product-slider-gallery .slick-arrow:hover , #elementor .tbay-element-nav-menu .dropdown-menu .elementor-nav-menu--main > ul > li:hover > a,#elementor .tbay-element-nav-menu .dropdown-menu .elementor-nav-menu--main > ul > li:focus > a,#elementor .tbay-element-nav-menu .dropdown-menu .elementor-nav-menu--main > ul > li.active > a,#elementor .tbay-element-nav-menu .dropdown-menu .elementor-nav-menu--main > ul > li > a:hover,#elementor .tbay-element-nav-menu .dropdown-menu .elementor-nav-menu--main > ul > li > a:focus,.header-default ul > li:hover a,.header-default ul > li:hover .caret::before,.header-default ul > li:focus a,.header-default ul > li:focus .caret::before,.header-default ul > li.active a,.header-default ul > li.active .caret::before,.header-default ul > li.active-mega-menu:hover .caret:before,.header-default ul > li.active-mega-menu:focus .caret:before,.header-default ul > li.menu-item-has-children:hover .caret:before,.header-default ul > li.menu-item-has-children:focus .caret:before,.header-default ul > li.menu-item-has-children .dropdown-menu > li:hover > a,.header-default ul > li.menu-item-has-children .dropdown-menu > li:focus > a,.header-default ul > li.menu-item-has-children .dropdown-menu > li.active > a,.header-default ul .dropdown-menu ul > li:hover a,.header-default ul .dropdown-menu ul > li:focus a,.header-default ul .dropdown-menu ul > li.active a,.show-all:hover,.tbay-element-banner-close .banner-remove:hover,.tbay-element-banner-close .banner-remove:focus,.featured-vendor .elementor-widget-wrap .elementor-button,.collaborate .tbay-element.tbay-element-heading .heading-tbay-title .title,.elementor-widget-icon-box .elementor-icon-box-wrapper .elementor-icon , .tbay-element-features .fbox-icon , .elementor-widget-besa-posts-grid .readmore,.tbay-element-instagram .btn-follow:hover,.tbay-element-instagram .btn-follow:hover span,.our-team-content .social-link a:hover,.product-block div.button-wishlist .yith-wcwl-add-to-wishlist > div.yith-wcwl-add-button a.delete_item,.product-block .add-cart a.added + a.added_to_cart,.product-block ul.show-brand a:hover,.product-block .name a:hover,.tbay-product-slider-gallery .slick-arrow:hover i,.tbay-product-slider-gallery .slick-arrow:focus i,.style-2 .custom-image-list-categories .item-cat i,.custom-image-list-categories .cat-name:hover,.custom-image-list-tags .tag-name:hover , .tbay-element.tbay-element-product-flash-sales .show-all,.elements .vc_row .flash-sales-date .times,.heading-product-category-tabs .btn:hover , .product-recently-viewed-header:hover h3,.product-recently-viewed-header:hover i,.product-recently-viewed-header:hover h3:after , .product-recently-viewed-header .btn-readmore,.product-recently-viewed-header h3:hover , .product-recently-viewed-main a.btn-readmore,.tbay-element-product-list-tags .item a:before , .post .entry-category.type-2 a,.entry-meta-list .entry-author a,.entry-title a:hover,.post .entry-category a,.style-grid .post .entry-category a,.related-posts .post .entry-category a,.post-area .entry-meta,.post-area .entry-meta a , .tagcloud a:hover,.entry-single .entry-category a,.entry-single .author-info .all-post,#comments .comment-reply-link,#comments .comment-reply-title #cancel-comment-reply-link,#comments .comment-edit-link,.contact-wrapper .contact-info li a,.page-404 .backtohome,.page-404 .contactus,.flex-control-nav > .slick-arrow:hover,.woocommerce-currency-switcher-form .SumoSelect > .CaptionCont:hover,.woocommerce-currency-switcher-form .SumoSelect > .CaptionCont:hover label i:after,.SumoSelect > .optWrapper > .options li.opt:hover,.SumoSelect > .optWrapper > .options li.opt.selected,.mm-listitem.active > a,.mm-menu .mm-navbar_tabs a,.mm-menu .mm-navbars_bottom .mm-navbar a:hover,.mm-menu .mm-navbars_bottom .mm-navbar a:focus,.yith-wfbt-submit-block .price_text > span.total_price,#cboxClose:hover:before,#cboxClose:focus:before,body.tbay-body-compare #yith-woocompare ins.woocommerce-Price-amount,body.tbay-body-compare #yith-woocompare .woocommerce-Price-amount,#tbay-quick-view-modal .mfp-close:hover,span.question a:hover,#show-all-questions a.show-questions:hover , #tab-questions a.back-to-product,.woocommerce table.wishlist_table.shop_table tr .product-remove a:hover,.woocommerce table.wishlist_table.shop_table .product-price,.woocommerce table.wishlist_table.shop_table .product-price .woocommerce-Price-amount,.woocommerce table.wishlist_table.shop_table .product-price ins span,.woocommerce.yith-wfbt-slider-wrapper .owl-item .yith-wfbt-single-product.product .product-price .woocommerce-Price-amount,.woocommerce.yith-wfbt-slider-wrapper .owl-item .yith-wfbt-single-product.product .product-price ins,.wishlist_table.mobile li .item-wrapper .item-details .woocommerce-Price-amount,.all-subcategories a:hover h3,.product-top-sidebar .button-product-top:focus,.product-top-sidebar .button-product-top:hover,.tbay-filter .SumoSelect > .CaptionCont:hover,.tbay-filter .SumoSelect.open .CaptionCont,.display-mode-warpper .display-mode-btn.active,.display-mode-warpper .display-mode-btn:hover,.woof_list > label:hover,.woof_childs_list_opener:hover , .cart-dropdown .subtotal,.tbay-dropdown-cart .cart_empty > li a.button,.cart-dropdown .cart_empty > li a.button,.tbay-dropdown-cart .cart_list a.remove:hover i,.cart-dropdown .cart_list a.remove:hover i,.tbay-dropdown-cart .cart_list .product-name:hover,.cart-dropdown .cart_list .product-name:hover,.tbay-dropdown-cart .cart_list .group .woocommerce-Price-amount,.cart-dropdown .cart_list .group .woocommerce-Price-amount , .tbay-dropdown-cart .total .woocommerce-Price-amount,.cart-dropdown .total .woocommerce-Price-amount,.tbay-dropdown-cart .widget-header-cart .offcanvas-close:hover,.tbay-dropdown-cart .widget-header-cart .offcanvas-close:focus,.tbay-element-mini-cart .product-image a.remove:hover i,#product-size-guide .close:hover i,#product-size-guide .close:focus i , .btn-size-guide,.singular-shop div.product .tbay-wishlist a:hover,.singular-shop div.product .tbay-wishlist a.added,.singular-shop div.product .tbay-compare a:hover,.singular-shop div.product .tbay-compare a.added , .singular-shop div.product .tbay-wishlist a.delete_item,.singular-shop div.product .product_meta > span a:hover,.woocommerce .quantity button:focus,.woocommerce .quantity button:hover,.woocommerce-page .quantity button:focus,.woocommerce-page .quantity button:hover,#shop-now.has-buy-now .group-button .tbay-wishlist .yith-wcwl-wishlistexistsbrowse a,#shop-now.has-buy-now .group-button .tbay-wishlist .yith-wcwl-wishlistaddedbrowse a,.product-nav > .link-images > .psnav .single_nav .single_nav a:hover,.product-nav > .link-images > .psnav .single_nav .single_nav a:focus,.product-nav .single_nav a:hover,.product-nav .single_nav a:focus,.woocommerce div.product div.images .woocommerce-product-gallery__trigger:hover,body div.product div.images .woocommerce-product-gallery__trigger:hover , .woocommerce .woocommerce-product-rating .woocommerce-review-link , .woocs_special_price_code , .woocs_price_code,.woocommerce-grouped-product-list-item__price , .woocommerce div.product p.price,.woocommerce div.product span.price,#reviews .wcpr-filter-button:hover,#reviews .wcpr-filter-button.wcpr-active , .wvs-css .variations .reset_variations,.tawcvs-swatches .swatch.selected,.tawcvs-swatches .swatch:hover,#sticky-menu-bar li.current a,#sticky-menu-bar li:hover a,#sticky-menu-bar li:focus a,#sticky-menu-bar li a:hover,#sticky-menu-bar li a:focus,.wc-tabs-wrapper .tabs-title button:hover,.wc-tabs-wrapper .tabs-title button:focus,.shop_table.cart a.remove:hover i,.cart_totals table tr.shipping .button,.cart_totals table * tr.shipping .button,.cart_totals table tr.shipping .button:hover,.cart_totals table * tr.shipping .button:hover,.cart_totals table tr.order-total .woocommerce-Price-amount,.cart_totals .shipping-calculator-form p:not(.form-row),.cart-bottom .continue-to-shop a:hover,.cart-bottom .update-cart:hover,.cart-bottom .update-cart:hover .update,.cart-bottom .update:hover,.cart-bottom .update:focus , .cart-collaterals .shipping-calculator-button,.woocommerce .shop_table .product-name > a:hover,.woocommerce .shop_table .product-name .wc-item-meta p,.woocommerce .shop_table .product-name dl.variation p , .woocommerce .woocommerce-MyAccount-content a:not(.woocommerce-button):not(.vendor-dashboard),.woocommerce form.login .lost_password a,.woocommerce form.register .lost_password a , .woocommerce form.register .woocommerce-privacy-policy-text a,.woocommerce .woocommerce-form-login-toggle .woocommerce-info a,.woocommerce .woocommerce-form-coupon-toggle .woocommerce-info a,form.checkout .order-review .shop_table > tfoot > tr.order-total > td .woocommerce-Price-amount,form.checkout .order-review .shop_table > tfoot > tr:last-child > th,.woocommerce-checkout-payment .place-order .woocommerce-terms-and-conditions-wrapper a,#custom-register a.text-link,#custom-login a.text-link,#custom-register .vendor-register a,.sold-by-meta > a:hover , .dokan-message a,.sold-dokan a:hover,ul.subsubsub li.active a,.dokan-seller-listing .wrapper-dokan > span:hover,.dokan-seller-listing .dokan-seller-search-form button:hover,.dokan-withdraw-content .dokan-withdraw-area ul li.active a,.become-vendor #tbay-main-content .tbay-addon-features:not(.style-2):not(.style-3) .inner:hover .fbox-icon , .become-vendor #tbay-main-content .tbay-addon-features:not(.style-2):not(.style-3) .fbox-icon,.dokan-orders-content .dokan-orders-area > a.dokan-btn:hover , .dokan-orders-content .dokan-orders-area .dokan-table .woocommerce-Price-amount,.wcmp_regi_main .register .woocommerce-privacy-policy-text a,#wcmp-store-conatiner .wcmp-store-list .wcmp-store-detail-wrap .wcmp-store-detail-list li .store-name:hover,#wcmp-store-conatiner .wcmp-store-list .wcmp-store-detail-wrap .wcmp-store-detail-list li .wcmp_vendor_detail,#custom-register .wcfmmp_become_vendor_link a , #wcfmmp-store ins,#wcfmmp-store .categories_list ul li a:hover,#wcfmmp-store .categories_list ul li a:focus,.woocommerce form.register .wcfmmp_become_vendor_link a,.wcv-dashboard-navigation ul li a:hover,table.table-vendor-sales-report a,table.table-vendor-sales-report tr td.product a , .shop_settings #main-container form #pv_shop_description_container > p a,form[name=export_orders] ~ table.table .order-comments-link,.product-block .wcvendors_sold_by_in_loop a:hover,.wcvendors-pro-dashboard-wrapper .wcv-navigation ul.menu li a:hover,.wcvendors-pro-dashboard-wrapper .wcv-navigation ul.menu li.active a,.wcvendors-pro-dashboard-wrapper .wcv-tabs.top .tabs-nav li a , .wcv-grid a:hover , table.wcv-table.wcvendors-table-product a,table.wcvendors-table-order .row-actions-order a:hover,.wcv-store-header.header-modern .meta .social-icons a:hover,.tbay-search-mobile .sumo_product_cat .optWrapper .options li.opt.selected,.tbay-search-mobile .sumo_category .optWrapper .options li.opt.selected,#custom-login-wrapper .modal-content .modal-body .nav-tabs li.active a,.active-search-mobile .tbay-search-mobile .count,#tbay-mobile-menu-navbar.search-mobile-focus .tbay-search-mobile .count,.image-mains .show-mobile > div .yith-wcwl-wishlistexistsbrowse.show i,.products-list .product-block .group-buttons > div a.added,.cart_totals table .order-total .woocs_special_price_code,.product-block.v1 .button-wishlist.shown-mobile > div .yith-wcwl-wishlistaddedbrowse a,.product-block.v1 .button-wishlist.shown-mobile > div .yith-wcwl-wishlistexistsbrowse a{color:#1b73f4;}.has-after:after,.post .entry-category.type-2 a:after,.entry-meta-list .entry-author a:after,.entry-meta-list .entry-category a:after,.entry-single .entry-category a:after,#tab-questions a.back-to-product:after,.woocommerce form.login .lost_password a:after,.woocommerce form.register .lost_password a:after,.woocommerce form.register .wcfmmp_become_vendor_link a:after,.product-recently-viewed-main a.btn-readmore:hover,.icon-preview-box:hover .preview,#awesome-font .fontawesome-icon-list .fa-hover:hover .preview,.carousel .carousel-indicators .active , .woocommerce a.button.alt,.dokan-dashboard .dokan-dash-sidebar ul.dokan-dashboard-menu li.active,.dokan-dashboard .dokan-dash-sidebar ul.dokan-dashboard-menu li:hover,.pagination span.current,.pagination span:hover,.pagination a.current,.pagination a:hover,.tbay-pagination span.current,.tbay-pagination span:hover,.tbay-pagination a.current,.tbay-pagination a:hover , .btn-theme,.btn-default,.woocommerce-pagination a.button,.woof_container_inner_tags ul.woof_list label,.widget_price_filter .price_slider_amount .button,.show-view-all a,.tbay-element-banner .banner-content .style-btn,.tbay-element-newsletter button[type=submit],.widget-newletter button[type=submit],.btn-view-all,.post .entry-category.type-1 a,.post-list .readmore,.post-grid .readmore,.entry-single .entry-description a,.post-password-form input[type=submit],#comments #respond .form-submit input,#reviews #respond .form-submit input,.wpcf7-form .form-horizontal .wpcf7-submit,.woocommerce .yith-wfbt-submit-block .yith-wfbt-submit-button-remove,body table.compare-list .add-to-cart td a:not(.unstyled_button),body table.compare-list .add-to-cart td a,input#ywqa-submit-question,div#new-answer-header .ywqa_submit_answer,.woocommerce table.wishlist_table.shop_table .product-add-to-cart .add-cart a,.more_products a,.tbay-pagination-load-more a,.tbay-dropdown-cart .group-button p.buttons a.button,.cart-dropdown .group-button p.buttons a.button,.tbay-element-mini-cart .left-right .group-button p.buttons a.button,.tbay-element-mini-cart .left-right .group-button p.buttons a.button.checkout,.woocommerce button.button,.woocommerce a.button.wc-backward,.woocommerce a.woocommerce-button.view,.woocommerce button.button[name=track],#respond input#submit,.woocommerce #respond input#submit,.woocommerce input.button,.singular-shop div.product .single_add_to_cart_button,.singular-shop .tbay-modalButton,#shop-now.has-buy-now .tbay-buy-now,.woocommerce-grouped-product-list-item__quantity .add-cart a.button,#sticky-menu-bar #sticky-custom-add-to-cart,.cart_totals .wc-proceed-to-checkout a.checkout-button,.coupon .box input[type=submit],.woocommerce table.shop_table.account-orders-table a.view,.woocommerce table.shop_table.my_account_orders a.view,.woocommerce table.shop_table.dokan-rma-order-item-table a.view,.woocommerce table.shop_table.account-orders-table a.request_warranty,.woocommerce table.shop_table.my_account_orders a.request_warranty,.woocommerce table.shop_table.dokan-rma-order-item-table a.request_warranty,.woocommerce form.login p.last .button,.woocommerce form.register p.last .button,.woocommerce-order-received .order-again a,.woocommerce-checkout.wc-germanized .wc-gzd-order-submit button[type=submit],.woocommerce form.checkout_coupon > p.form-row-last .button,.woocommerce-checkout-payment .place-order button.button.alt,#custom-register input.submit_button,#custom-login input.submit_button,input[type=submit].dokan-btn,a.dokan-btn-theme,.dokan-btn-theme,.dokan-btn-success,input[type=submit].dokan-btn[disabled],a.dokan-btn-theme[disabled],.dokan-btn-theme[disabled],.dokan-btn-success[disabled],.dokan-dashboard .wpuf-form-add.wpuf-style ul.wpuf-form .wpuf-submit input[type=submit],.dokan-dashboard a.add_new_attribute,.dokan-add-new-product-popup input#dokan-create-new-product-btn,.dokan-seller-listing .store-footer > a,#dokan-seller-listing-wrap ul.dokan-seller-wrap li .store-footer .dokan-follow-store-button,.dokan-orders-content #dokan-order-status-form a.dokan-cancel-status,.wcmp_regi_main .register .button,#report_abuse_form button.submit-report-abuse,#report-abuse table input[type=submit],.vendor_sidebar .widget_wcmp_quick_info #respond input#submit,#wcmp-store-conatiner .wcmp-store-locator-wrap .wcmp-store-map-pagination .vendor_sort input[type=submit],#wcmp-store-conatiner .wcmp-store-map-filter input[type=submit],#wcfm-main-contentainer .wcfm-membership-wrapper input[type=submit],#wcfm-main-contentainer .wcfm_form_simple_submit_wrapper .wcfm_submit_button,.wcfm_popup_wrapper .wcfm_popup_button,#wcfmmp-store #reviews .add_review button,.form-row input[name=apply_for_vendor_submit],form.wcv-form .wcv-button[type=submit],.dashboard .wcv-dashboard-navigation ~ form input[type=submit],.shop_settings input[name=vendor_application_submit],form[name=export_orders] input,form[name=export_orders] ~ table.table .order-comments input.btn,.wcvendors-pro-dashboard-wrapper a.button,.wcvendors-pro-dashboard-wrapper .wcv-form .control-group .button,.wcvendors-pro-dashboard-wrapper input#update_button,.wcvendors-pro-dashboard-wrapper .wcv-search-form .wcv-button,.wcv-form .control-group .control > input.wcv-button:not(#clear_button),.wcv-order-header .wcv-form .control > input#clear_button,table.wcvendors-table-order .wcv-shade.wcv-fade .order_note_form input[type=submit],table.wcvendors-table-order form #tracking_number_save_button,form#wcv-store-settings input#store_save_button,.wcv_store_search form input[type=submit],.wcv_vendor_search form input[type=submit],.new-input:checked + span:before,.woof_container input[type=checkbox]:checked:not(.woof_color_term) + span:before,form.checkout input[type=radio]:checked + span:before,form.checkout input[type=checkbox]:checked + span:before,.woocommerce-account input[type=radio]:checked + span:before,.woocommerce-account input[type=checkbox]:checked + span:before,.yith-wfbt-section .yith-wfbt-item input[type=checkbox]:checked + span:before,.woocommerce form .form-row .woocommerce-form__input:checked + span:before,#custom-login-wrapper #cus-rememberme:checked + span:before,.new-input:checked + label:before,.woof_container input[type=checkbox]:checked:not(.woof_color_term) + label:before,form.checkout input[type=radio]:checked + label:before,form.checkout input[type=checkbox]:checked + label:before,.woocommerce-account input[type=radio]:checked + label:before,.woocommerce-account input[type=checkbox]:checked + label:before,.yith-wfbt-section .yith-wfbt-item input[type=checkbox]:checked + label:before,.woocommerce form .form-row .woocommerce-form__input:checked + label:before,#custom-login-wrapper #cus-rememberme:checked + label:before,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav .text-label.label-hot,.treeview .sub-menu a:hover:before , body:not(.tbay-body-default) .widget.yith-woocompare-widget a.compare,ul.woof_list.woof_list_color li .woof_label_count,ul.woof_list.woof_list_label li .woof_label_count , .woocommerce .widget_price_filter .ui-slider .ui-slider-range,.tbay-body-default .woocommerce-mini-cart__buttons > a.wc-forward.checkout,.product-block.v1 .group-buttons > div a:hover,.product-block.v10 .name a:hover:before,.product-block.v14 .group-buttons > div a.added,.product-block.v14 .group-buttons > div a.added + a.added_to_cart,.product-block.v14 .button-wishlist a:hover,.product-block.v14 .button-wishlist a:focus,.product-block.v14 .yith-wcwl-wishlistexistsbrowse.show a,.product-block.v14 .yith-wcwl-wishlistaddedbrowse.show a,.product-block.v15:hover .group-add-cart:hover,.elementor-product-vertical-v2 .owl-carousel > .slick-arrow:hover,.elementor-product-vertical-v2 .owl-carousel > .slick-arrow:focus,.show-all:before,.featured-vendor .elementor-widget-wrap .elementor-button:after , .elementor-widget-besa-posts-grid .post-type,#tbay-cart-modal .main-content a.view-cart:hover,#tbay-cart-modal .main-content a.checkout,.style-2 .custom-image-list-categories .item-cat:hover,.tbay-addon.product-countdown .tbay-addon-content .owl-carousel:before,.tbay-addon.product-countdown .tbay-addon-content .owl-carousel:after,.tbay-element.tbay-element-product-flash-sales .show-all:hover,.elements .vc_row .flash-sales-date .times > div span,.heading-product-category-tabs .btn:before,.product-recently-viewed-header .btn-readmore:hover,.tbay-element-product-list-tags .item:hover,.layout-blog .entry-thumb .post-type,.post.sticky .entry-title , .link-wrap,.page-links > span:not(.page-links-title),.page-links a:hover,.slick-dots li.slick-active button,.owl-carousel > .slick-arrow:hover,.owl-carousel > .slick-arrow:focus,.slider > .slick-arrow:hover,.slider > .slick-arrow:focus,body table.compare-list .add-to-cart td a:not(.unstyled_button):hover,body table.compare-list .add-to-cart td a:not(.unstyled_button):focus,body table.compare-list .add-to-cart td a:hover,.carousel .carousel-controls-v3 .carousel-control:hover,div.question-text .question-symbol,.woocommerce table.wishlist_table.shop_table tr .product-remove.icon a,.wishlist_table.mobile .product-add-to-cart .add-cart a,.tparrows:hover,.tp-bullets.revo-tbay .tp-bullet.selected,.tp-bullets.revo-tbay .tp-bullet:hover,.singular-shop div.product .single_add_to_cart_button.disabled,.singular-shop div.product .single_add_to_cart_button.disabled:hover,.singular-shop div.product .single_add_to_cart_button.disabled:focus , .progress-bar , #reviews .wcpr-overall-rating-left,.woocommerce-tabs-mobile .wc-tab-mobile .tab-head,.shop_table.cart .cart-bottom > *.update:hover,.shop_table.cart .cart-bottom > * a:hover,.woocommerce .woocommerce-MyAccount-navigation ul li.is-active a,.woocommerce .woocommerce-MyAccount-navigation ul li:hover a,.woocommerce .woocommerce-MyAccount-navigation ul li:focus a , input[type=submit].dokan-btn:active,input[type=submit].dokan-btn:focus,a.dokan-btn-theme:active,a.dokan-btn-theme:focus,.dokan-btn-theme:active,.dokan-btn-theme:focus,.dokan-btn-success:active,.dokan-btn-success:focus,.dokan-dashboard .dokan-dash-sidebar ul.dokan-dashboard-menu li.dokan-common-links a:hover,.dokan-dashboard .pagination-wrap > ul.pagination > li span.current,.dokan-dashboard .pagination-wrap > ul.pagination > li span:hover,.dokan-dashboard .pagination-wrap > ul.pagination > li a.current,.dokan-dashboard .pagination-wrap > ul.pagination > li a:hover,.dokan-pagination-container ul.dokan-pagination > li:not(.disabled):not(.active):hover a,.dokan-pagination-container ul.dokan-pagination > li.active a,.dokan-pagination-container ul.dokan-pagination > li a.current,#report-abuse table input[type=submit],#report-abuse table input[type=submit]:hover , .vendor_sidebar .widget_wcmp_quick_info #respond input#submit, .cart-dropdown .cart-icon .mini-cart-items{background-color:#1b73f4;}.pagination span.current,.pagination span:hover,.pagination a.current,.pagination a:hover,.tbay-pagination span.current,.tbay-pagination span:hover,.tbay-pagination a.current,.tbay-pagination a:hover,.new-input:checked + span:before,.woof_container input[type=checkbox]:checked:not(.woof_color_term) + span:before,form.checkout input[type=radio]:checked + span:before,form.checkout input[type=checkbox]:checked + span:before,.woocommerce-account input[type=radio]:checked + span:before,.woocommerce-account input[type=checkbox]:checked + span:before,.yith-wfbt-section .yith-wfbt-item input[type=checkbox]:checked + span:before,.woocommerce form .form-row .woocommerce-form__input:checked + span:before,#custom-login-wrapper #cus-rememberme:checked + span:before,.new-input:checked + label:before,.woof_container input[type=checkbox]:checked:not(.woof_color_term) + label:before,form.checkout input[type=radio]:checked + label:before,form.checkout input[type=checkbox]:checked + label:before,.woocommerce-account input[type=radio]:checked + label:before,.woocommerce-account input[type=checkbox]:checked + label:before,.yith-wfbt-section .yith-wfbt-item input[type=checkbox]:checked + label:before,.woocommerce form .form-row .woocommerce-form__input:checked + label:before,#custom-login-wrapper #cus-rememberme:checked + label:before , body:not(.tbay-body-default) .widget.yith-woocompare-widget a.compare,.woof_list_label li .woof_label_term.checked,ul.woof_list li > div.checked,ul.woof_list li > div:hover , .woocommerce .widget_price_filter .ui-slider .ui-slider-handle,.tagcloud a:hover,ul.list-tags li a:hover,.tbay-body-default .sidebar .tagcloud a:hover,.tbay-body-default .sidebar .tagcloud a:focus,.tbay-body-default .footer .tagcloud a:hover,.tbay-body-default .footer .tagcloud a:focus,.product-block.v1 .group-buttons > div a:hover,.product-block.v2 .group-buttons > div a:hover,.product-block.v4 .group-buttons > div a:hover,.product-block.v5 .group-buttons > div a:hover,.product-block.v6 .group-buttons > div a:hover,.product-block.v7 .group-buttons > div a:hover,.product-block.v8 ul.show-brand a:hover,.product-block.v8 .group-buttons > div a:hover,.product-block.v8 .group-buttons > div:last-child a:hover,.product-block.v9 .group-buttons > div a:hover,.product-block.v9 .tbay-swatches-wrapper li a.variable-item-span-image:hover,.product-block.v10 .group-buttons > div a:hover,.product-block.v10 .group-buttons > div:last-child a:hover,.product-block.v11 .group-buttons > div a:hover,.product-block.v11 .group-buttons > div:last-child a:hover,.product-block.v13 .group-buttons > div a:hover,.product-block.v14 .group-buttons > div a:hover,.product-block.v14 .group-buttons > div a.added,.product-block.v14 .group-buttons > div a.added + a.added_to_cart,.product-block.v14 .button-wishlist a:hover,.product-block.v14 .button-wishlist a:focus,.product-block.v14 .yith-wcwl-wishlistexistsbrowse.show a,.product-block.v14 .yith-wcwl-wishlistaddedbrowse.show a,.product-block.v15 .group-buttons > div a:hover,#tbay-cart-modal .main-content a.view-cart:hover,#tbay-cart-modal .main-content a.checkout,.style-2 .custom-image-list-categories .item-cat:hover , .tbay-addon.product-countdown .tbay-addon-content , .tbay-element.tbay-element-product-flash-sales .show-all , .product-recently-viewed-header .btn-readmore , .product-recently-viewed-main a.btn-readmore,.tbay-element-product-list-tags .item:hover , .post.sticky , .post-area .sticky,.page-links > span:not(.page-links-title),.page-links a:hover,.owl-carousel > .slick-arrow:hover,.owl-carousel > .slick-arrow:focus,.slider > .slick-arrow:hover,.slider > .slick-arrow:focus,.carousel .carousel-controls-v3 .carousel-control:hover,.tbay-body-woocommerce-catalog-mod .product-block.v1 .group-buttons > div.button-wishlist a:hover,.tbay-body-woocommerce-catalog-mod .product-block.v2 .group-buttons > div.button-wishlist a:hover,.tbay-body-woocommerce-catalog-mod .product-block.v6 .group-buttons > div.tbay-quick-view a:hover,.tbay-body-woocommerce-catalog-mod .product-block.v11 .group-buttons > div.tbay-quick-view a:hover,.tbay-body-woocommerce-catalog-mod .products-list .product-block .group-buttons > div.tbay-quick-view a:hover,.tbay-element-mini-cart .product-image a.remove:hover i,.singular-shop div.product .flex-control-thumbs .slick-list li img.flex-active,.singular-shop div.product .flex-control-thumbs .slick-list li img:hover,.product-nav .single_nav a:hover,.product-nav .single_nav a:focus,.woocommerce div.product div.images .woocommerce-product-gallery__trigger:hover,body div.product div.images .woocommerce-product-gallery__trigger:hover,.tawcvs-swatches .swatch.selected,.tawcvs-swatches .swatch:hover,.dokan-dashboard .pagination-wrap > ul.pagination > li span.current,.dokan-dashboard .pagination-wrap > ul.pagination > li span:hover,.dokan-dashboard .pagination-wrap > ul.pagination > li a.current,.dokan-dashboard .pagination-wrap > ul.pagination > li a:hover,.dokan-pagination-container ul.dokan-pagination > li:not(.disabled):not(.active):hover a,.dokan-pagination-container ul.dokan-pagination > li.active a,.dokan-pagination-container ul.dokan-pagination > li a.current{border-color:#1b73f4;}#tbay-search-form-canvas .tbay-loading:after,.elementor-widget-besa-nav-menu .tbay-horizontal .navbar-nav .text-label.label-hot:before,.display-products.load-ajax:after{border-top-color:#1b73f4;}blockquote{border-left-color:#1b73f4;}.tbay-search-form .button-group,.cart-dropdown .cart-icon span.mini-cart-items,.tbay-search-form .button-search:not(.icon) , .top-wishlist .count_wishlist , .singular-shop div.product.product-type-external .single_add_to_cart_button{background-color:#1b73f4;}</style></head>
<body class="rtl error404 theme-besa woocommerce-no-js tbay-body-loader tbay-show-cart-mobile tbay-body-mobile-product-two  tbay-show-quantity-mobile elementor-default elementor-kit-108 woocommerce ajax_cart_popup header-mobile-center dokan-theme-besa">
					<div class="tbay-page-loader">
					    <div class="tbay-loader tbay-loader-six"> <span class=" spinner-cube-1 spinner-cube"></span> <span class=" spinner-cube-2 spinner-cube"></span> </div>
					</div>
	    			<div id="wrapper-container" class="wrapper-container">
 
	  
<div id="tbay-mobile-smartmenu" data-enablebottom="true" data-enablesocial="true" data-socialjsons="[{'icon':'fa fa-telegram','url':'#'},{'icon':'fa fa-youtube','url':'#'},{'icon':'fa fa-instagram','url':'#'},{'icon':'fa fa-twitter','url':'#'}]" data-enabletabs="1" data-tabone="منو" data-taboneicon="fa fa-bars" data-tabsecond="دسته بندی ها" data-tabsecondicon="icons icon-grid" data-enableeffects="1" data-effectspanels="no-effect" data-effectslistitems="fx-listitems-fade" data-counters="1" data-title="منوی فروشگاه" class="tbay-mmenu d-xl-none"> 

            <div id="mm-searchfield" class="mm-searchfield__input" >

                        <div class="mmenu-account">
                <div id="mobile-menu-third-mmenu" class="menu-my-account-container"><ul id="main-mobile-third-mmenu-wrapper" class="menu"><li id="menu-item-188" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/orders/">سفارش‌ها</a></li>
<li id="menu-item-189" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/downloads/">دانلودها</a></li>
<li id="menu-item-190" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/edit-address/">آدرس‌ها</a></li>
<li id="menu-item-191" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/edit-account/">جزئیات حساب</a></li>
<li id="menu-item-193" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/lost-password/">فراموشی گذرواژه</a></li>
</ul></div>            </div>
            
        </div>

    
    <div class="tbay-offcanvas-body">

        <nav id="tbay-mobile-menu-navbar" class="navbar navbar-offcanvas navbar-static">
            <div id="main-mobile-menu-mmenu" class="menu-my-account-container"><ul id="main-mobile-menu-mmenu-wrapper" class="menu"><li class="menu-item menu-item-type-custom menu-item-object-custom"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/orders/">سفارش‌ها</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/downloads/">دانلودها</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/edit-address/">آدرس‌ها</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/edit-account/">جزئیات حساب</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/lost-password/">فراموشی گذرواژه</a></li>
</ul></div><div id="mobile-menu-second-mmenu" class="menu-my-account-container"><ul id="main-mobile-second-mmenu-wrapper" class="menu"><li class="menu-item menu-item-type-custom menu-item-object-custom"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/orders/">سفارش‌ها</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/downloads/">دانلودها</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/edit-address/">آدرس‌ها</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/edit-account/">جزئیات حساب</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/lost-password/">فراموشی گذرواژه</a></li>
</ul></div>        </nav>


    </div>
</div>
	<div class="topbar-device-mobile d-xl-none clearfix ">

	<div class="active-mobile"><a href="#tbay-mobile-menu-navbar" class="btn btn-sm"><i class="tb-icon tb-icon-menu"></i></a><a href="#page" class="btn btn-sm"><i class="tb-icon tb-icon-cross"></i></a></div><div class="mobile-logo"><a href="http://besa.automatic.agency/snapp-market/"><img src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/besamarket-logo.png" width="1000" height="485" alt="قالب بسامارکت | دموی اختصاصی اسنپ مارکت"></a></div>		<div class="top-right-mobile">
						<div class="search-device">
				<a id="search-icon" class="search-icon" href="javascript:;"><i class="tb-icon tb-icon-magnifier"></i></a>
				
	
		<div class="tbay-search-form tbay-search-mobile">
		    <form action="http://besa.automatic.agency/snapp-market/" method="get" data-parents=".topbar-device-mobile" class="searchform besa-ajax-search" data-search-in="only_title" data-appendto=".search-results-UP7e8" data-thumbnail="1" data-price="1" data-minChars="2" data-post-type="product" data-count="5">
			<div class="form-group">
				<div class="input-group">
											<div class="select-category input-group-addon">
							 
							<select  name='product_cat' id='product-cat-UP7e8' class='dropdown_product_cat' >
	<option value='' selected='selected'>همه</option>
	<option class="level-0" value="%d8%a8%d8%af%d9%88%d9%86-%d8%af%d8%b3%d8%aa%d9%87%e2%80%8c%d8%a8%d9%86%d8%af%db%8c">بدون دسته‌بندی&nbsp;&nbsp;(9)</option>
	<option class="level-0" value="%d8%a8%db%8c%d8%b3%da%a9%d9%88%db%8c%d8%aa">بیسکویت&nbsp;&nbsp;(5)</option>
	<option class="level-0" value="%d8%ae%d9%88%d8%a7%d8%b1%d8%a8%d8%a7%d8%b1">خواربار&nbsp;&nbsp;(3)</option>
	<option class="level-0" value="%d8%af%d8%b3%d8%aa%d9%85%d8%a7%d9%84-%d9%88-%d8%b4%d9%88%db%8c%d9%86%d8%af%d9%87">دستمال و شوینده&nbsp;&nbsp;(3)</option>
	<option class="level-0" value="%d8%af%d8%b3%d8%b1">دسر&nbsp;&nbsp;(2)</option>
	<option class="level-0" value="%da%a9%d9%86%d8%b3%d8%b1%d9%88">کنسرو&nbsp;&nbsp;(2)</option>
	<option class="level-0" value="%d9%84%d8%a8%d9%86%db%8c%d8%a7%d8%aa">لبنیات&nbsp;&nbsp;(4)</option>
	<option class="level-0" value="%d9%85%d9%88%d8%a7%d8%af-%d9%be%d8%b1%d9%88%d8%aa%d8%a6%db%8c%d9%86%db%8c">مواد پروتئینی&nbsp;&nbsp;(2)</option>
	<option class="level-0" value="%d9%86%d8%a7%d9%86-%d9%88-%d8%b4%db%8c%d8%b1%db%8c%d9%86%db%8c">نان و شیرینی&nbsp;&nbsp;(2)</option>
</select>
							
							
						</div>
					
					<input data-style="right" type="text" placeholder="جستجو برای محصولات ..." name="s" required oninvalid="this.setCustomValidity('حداقل 2 کارکتر وارد کنید')" oninput="setCustomValidity('')" class="tbay-search form-control input-sm"/>

					<span class="button-search-cancel">
						<i class="tb-icon tb-icon-cross"></i>
					</span>
					<div class="search-results-wrapper"> 	 
						<div class="besa-search-results search-results-UP7e8" data-ajaxsearch="1" data-price="1"></div>
					</div>
					<input type="hidden" name="post_type" value="product" class="post_type" />
				</div>
				
			</div>
		</form>

	</div>
			</div>

				</div>
	</div>	
		
<div class="footer-device-mobile d-xl-none clearfix">

    <div class="device-home  "><a href="http://besa.automatic.agency/snapp-market/" ><i class="tb-icon tb-icon-home3"></i><span>خانه</span></a></div><div class="device-wishlist"><a class="text-skin wishlist-icon" href="http://besa.automatic.agency/snapp-market/wishlist/" ><i class="tb-icon tb-icon-heart"></i><span class="count count_wishlist">24</span><span>علاقه مندی ها</span></a></div>
        <div class="device-mini_cart top-cart tbay-element-mini-cart">
        	<div class="tbay-dropdown-cart sidebar-right">
	<div class="dropdown-content">
		<div class="widget-header-cart">
			<h3 class="widget-title heading-title">سبد خرید</h3>
			<a href="javascript:;" class="offcanvas-close"><i class="tb-icon tb-icon-cross"></i></a>
		</div>
		<div class="widget_shopping_cart_content">
	    
<div class="mini_cart_content">
	<div class="mini_cart_inner">
		<div class="mcart-border">
							<ul class="cart_empty ">
					<li><span>سبد خرید خالی است</span></li>
					<li class="total"><a class="button wc-continue" href="http://besa.automatic.agency/snapp-market/shop/">ادامه خرید<i class="tb-icon tb-icon-chevron-right"></i></a></li>
				</ul>
			
						<div class="clearfix"></div>
		</div>
	</div>
</div>
		</div>
	</div>
</div>            <div class="tbay-topcart">
				<div id="cart-1yxYu" class="cart-dropdown dropdown">
					<a class="dropdown-toggle mini-cart v2" data-offcanvas="offcanvas-right" data-toggle="dropdown" aria-expanded="true" role="button" aria-haspopup="true" data-delay="0" href="#">
													<i class="tb-icon tb-icon-cart"></i>
						
													<span class="mini-cart-items">
							   0							</span>
						<span>سبد خرید</span>
					</a>   
					<div class="dropdown-menu"></div>    
				</div>
			</div> 
		</div>

		<div class="device-recent "><a class="mobile-recent" href="http://besa.automatic.agency/snapp-market/recently-viewed/" ><i class="fal fa-eye"></i><span>مشاهده شده</span></a></div><div class="device-account "><a class="popup-login" href="javascript:void(0);"  title="ورود"><i class="tb-icon tb-icon-user"></i><span>حساب کاربری</span></a></div>
</div>
	
<div id="custom-login-wrapper" class="modal fade" role="dialog">

    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <button type="button" class="btn-close" data-dismiss="modal"><i class="tb-icon tb-icon-cross2"></i></button>
            <div class="modal-body">

                <ul class="nav nav-tabs">
                    <li><a data-toggle="tab" class="active" href="#tab-customlogin"><i class="tb-icon tb-icon-user d-xl-none"></i>ورود</a></li>

                                        <li><a data-toggle="tab" href="#tab-customregister"><i class="tb-icon tb-icon-pencil4 d-xl-none"></i>ثبت نام</a></li>
                    
                </ul>

                <div class="tab-content clearfix">
                    <div id="tab-customlogin" class="tab-pane fade show active">
                        <form id="custom-login" class="ajax-auth" action="login" method="post">
                            
                            <h3>برای ورود، نام کاربری و کلمه عبور را وارد کنید.</h3>
                            <p class="status"></p>  
                            <input type="hidden" id="security" name="security" value="3f8a1b0d58" /><input type="hidden" name="_wp_http_referer" value="/snapp-market/popper.js" />  
                            <input id="cus-username" type="text" placeholder="نام کاربری/ایمیل" class="required form-control" name="username" autocomplete="username" value="">
                            <input id="cus-password" type="password" placeholder="کلمه عبور" class="required form-control" name="password" autocomplete="current-password"> 
                            
                            <div class="rememberme-wrapper">
                                <input name="rememberme" type="checkbox" id="cus-rememberme" value="forever">
                                <label for="cus-rememberme">مرا به خاطر بسپار</label>
                            </div>
                            <a id="pop_forgot" class="text-link" href="http://besa.automatic.agency/snapp-market/my-account/lost-password/">فراموشی کلمه عبور؟</a>
                            <input class="submit_button" type="submit" value="ورود">

                            <div class="clear"></div>
                                                    </form>
                    </div>

                                        <div id="tab-customregister" class="tab-pane fade">
                        <form id="custom-register" class="ajax-auth"  action="register" method="post">
                            
                            <h3>برای ایجاد حساب کاربری، فرم را تکمیل کنید</h3>
                            <p class="status"></p>
                            <input type="hidden" id="signonsecurity" name="signonsecurity" value="335994f6af" /><input type="hidden" name="_wp_http_referer" value="/snapp-market/popper.js" />         
                            <input id="signonname" type="text" placeholder="نام کاربری" name="signonname" class="required form-control" value="">
                            <input id="signonemail" type="text" placeholder="ایمیل" class="required email form-control" name="email" autocomplete="email" value="">
                            <input id="signonpassword" type="password" placeholder="کلمه عبور" class="required form-control" name="signonpassword" autocomplete="new-password">
                            <input type="password" id="password2" placeholder="تایید کلمه عبور" class="required form-control" name="password2" autocomplete="new-password">
                            <input class="submit_button" type="submit" value="ثبت نام">

                            <div class="clear"></div>
                            <div class="vendor-register">آیا فروشنده هستید؟ <a href="http://besa.automatic.agency/snapp-market/my-account/">از اینجا ثبت نام کنید</a></div>                                                    </form>
                    </div>
                                    </div>
            </div>
        </div>
    </div>
</div>
<header id="tbay-header" class="tbay_header-template site-header">

		

				<div data-elementor-type="wp-post" data-elementor-id="106" class="elementor elementor-106" data-elementor-settings="[]">
						<div class="elementor-inner">
							<div class="elementor-section-wrap">
							<section class="elementor-section elementor-top-section elementor-element elementor-element-573d582e elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="573d582e" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-7937a101" data-id="7937a101" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-24db4c43 elementor-widget w-auto elementor-widget-besa-mini-cart" data-id="24db4c43" data-element_type="widget" data-widget_type="besa-mini-cart.default">
				<div class="elementor-widget-container">
			<div class="tbay-element tbay-element-mini-cart">
    <div class="tbay-topcart popup">
 <div id="cart-DLWVH" class="cart-dropdown cart-popup dropdown">
        <a class="dropdown-toggle mini-cart" data-toggle="dropdown" aria-expanded="true" role="button" aria-haspopup="true" data-delay="0" href="javascript:void(0);" title="مشاهده سبد خریدتان">
			
        <span class="cart-icon">

                            <i class="tb-icon tb-icon-cart"></i>
                        <span class="mini-cart-items">
               0            </span>
        </span>

                    <span class="text-cart">

                            <span>سبد خرید</span>
            
            
        </span>

                </a>            
        <div class="dropdown-menu">
        	<div class="widget-header-cart">
								
				<a href="javascript:;" class="offcanvas-close"><i class="tb-icon tb-icon-cross"></i></a>
			</div> 
        	<div class="widget_shopping_cart_content">
            	
<div class="mini_cart_content">
	<div class="mini_cart_inner">
		<div class="mcart-border">
							<ul class="cart_empty ">
					<li><span>سبد خرید خالی است</span></li>
					<li class="total"><a class="button wc-continue" href="http://besa.automatic.agency/snapp-market/shop/">ادامه خرید<i class="tb-icon tb-icon-chevron-right"></i></a></li>
				</ul>
			
						<div class="clearfix"></div>
		</div>
	</div>
</div>
       		</div>
    	</div>
    </div>
</div>     </div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-d353b8d" data-id="d353b8d" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="column-element-child-border elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-39e0b049 elementor-widget w-auto elementor-widget-besa-account" data-id="39e0b049" data-element_type="widget" data-widget_type="besa-account.default">
				<div class="elementor-widget-container">
			    <div class="tbay-element tbay-element-account header-icon">
        <div class="tbay-login">
                                        <a data-toggle=modal data-target=#custom-login-wrapper href="#custom-login-wrapper">
                                <i aria-hidden="true" class="tb-icon tb-icon-user"></i><span class="text-account"> ورود یا ثبت نام </span>                            </a>  
                                </div>
</div>
		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-530d07de" data-id="530d07de" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-320d406a elementor-widget elementor-widget-besa-search-form" data-id="320d406a" data-element_type="widget" data-widget_type="besa-search-form.default">
				<div class="elementor-widget-container">
			        <div class="tbay-element tbay-element-search-form">
                        <div class="tbay-search-form">
                <form action="http://besa.automatic.agency/snapp-market/" method="get" class="besa-ajax-search searchform" data-thumbnail="1" data-appendto=".search-results-wawBY" data-price="1" data-minChars="2" data-post-type="product" data-count="5" >
                    <div class="form-group">
                        <div class="input-group">
                                                            <input data-style="right" type="text" placeholder="جستجوی محصول یا برند (شیر، پوشک، کاله و...)" name="s" required oninvalid="this.setCustomValidity('حداقل 2 کارکتر وارد کنید')" oninput="setCustomValidity('')" class="tbay-search form-control input-sm"/>

                                <div class="search-results-wrapper">
                                    <div class="besa-search-results search-results-wawBY" ></div>
                                </div>
                                <div class="button-group input-group-addon">
                                    <button type="submit" class="button-search btn btn-sm>">
                                        <i aria-hidden="true" class="linear-icon-magnifier"></i>                                                                            </button>
                                    <div class="tbay-preloader"></div>
                                </div>

                                <input type="hidden" name="post_type" value="product" class="post_type" />
                        </div>
                        
                    </div>
                </form>
            </div>
                </div>
    		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-d6b4322" data-id="d6b4322" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-5e55b425 elementor-widget elementor-widget-image" data-id="5e55b425" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
											<a href="http://besa.automatic.agency/snapp-market">
							<img width="300" height="146" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/besamarket-logo-300x146.png" class="attachment-medium size-medium" alt="" loading="lazy" />								</a>
											</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-752a10d9 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="752a10d9" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-7fe50e68" data-id="7fe50e68" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-11aacbd3 elementor-align-right elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="11aacbd3" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="icon- icon-location-pin"></i>						</span>
										<span class="elementor-icon-list-text">آدرس ما: <br> تهران، فلسطین - انقلاب، میدان انقلاب اسلامی</span>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-24a6d3f3" data-id="24a6d3f3" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-7c4c8800 elementor-nav-menu__align-center elementor-widget elementor-widget-besa-nav-menu" data-id="7c4c8800" data-element_type="widget" data-settings="{&quot;layout&quot;:&quot;horizontal&quot;}" data-widget_type="besa-nav-menu.default">
				<div class="elementor-widget-container">
			<div class="tbay-element tbay-element-nav-menu" data-wrapper="{&quot;layout&quot;:&quot;horizontal&quot;}">
		
	
					<nav class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal tbay-horizontal"><ul id="menu-1-qnSrT" class="elementor-nav-menu nav navbar-nav megamenu flex-row"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-187 level-0 aligned-left"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/"><i class="fal fa-home"></i>صفحه اصلی</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-186 level-0 aligned-left"><a class="elementor-item" href="http://besa.automatic.agency/snapp-market/wishlist/"><i class="fal fa-heart"></i>علاقه مندی</a></li>
</ul></nav>
	
</div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-73acf600" data-id="73acf600" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-6eacde65 elementor-view-default elementor-widget elementor-widget-icon" data-id="6eacde65" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<div class="elementor-icon">
			<i aria-hidden="true" class="icon- icon-eye"></i>			</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-51d1a626 elementor-widget elementor-widget-besa-product-recently-viewed" data-id="51d1a626" data-element_type="widget" data-widget_type="besa-product-recently-viewed.default">
				<div class="elementor-widget-container">
			
<div class="tbay-element tbay-element-product-recently-viewed product-recently-viewed-header" data-wrapper="{&quot;layout&quot;:&quot;header&quot;}" data-column="8">

    
    
        <h3 class="header-title">
            اجناسی که اخیرا بازدید کرده اید!        </h3>
        <div class="content-view ">
            <div class="list-recent">
                <div class="product-item">
	<a title="پودر ژله با طعم تمشک فرمند ۱۰۰ گرمی" href="http://besa.automatic.agency/snapp-market/product/%d9%be%d9%88%d8%af%d8%b1-%da%98%d9%84%d9%87-%d8%a8%d8%a7-%d8%b7%d8%b9%d9%85-%d8%aa%d9%85%d8%b4%da%a9-%d9%81%d8%b1%d9%85%d9%86%d8%af-%db%b1%db%b0%db%b0-%da%af%d8%b1%d9%85%db%8c/" class="product-image">
		<img width="280" height="280" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/hph-20590-280x280.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy" />	</a>
</div>
            
                
<div class="product-item">
	<a title="ارده و شیره خرما عقاب مقدار 1050 گرم" href="http://besa.automatic.agency/snapp-market/product/%d8%a7%d8%b1%d8%af%d9%87-%d9%88-%d8%b4%db%8c%d8%b1%d9%87-%d8%ae%d8%b1%d9%85%d8%a7-%d8%b9%d9%82%d8%a7%d8%a8-%d9%85%d9%82%d8%af%d8%a7%d8%b1-1050-%da%af%d8%b1%d9%85/" class="product-image">
		<img width="280" height="280" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/1219942-280x280.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy" />	</a>
</div>
            
                
<div class="product-item">
	<a title="تخم مرغ تلاونگ بسته 20 عددی" href="http://besa.automatic.agency/snapp-market/product/%d8%aa%d8%ae%d9%85-%d9%85%d8%b1%d8%ba-%d8%a8%d9%87%d8%af%db%8c%d9%86-%db%b9-%d8%b9%d8%af%d8%af%db%8c/" class="product-image">
		<img width="280" height="280" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/3573133-280x280.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy" />	</a>
</div>
            
                
<div class="product-item">
	<a title="ران گوسفندی مهیا پروتئین &#8211; 1 کیلوگرم" href="http://besa.automatic.agency/snapp-market/product/%da%af%d9%88%d8%b4%d8%aa-%da%86%d8%b1%d8%ae-%da%a9%d8%b1%d8%af%d9%87-%d9%85%d8%ae%d9%84%d9%88%d8%b7-%d9%be%d9%88%db%8c%d8%a7-%db%b8%db%b0%db%b0-%da%af%d8%b1%d9%85%db%8c/" class="product-image">
		<img width="280" height="280" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/111951307-280x280.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy" />	</a>
</div>
            
                
<div class="product-item">
	<a title="مایع دستشویی گلیسیرینه ایکو مویست مدل Green حجم 3750 میلی لیتر" href="http://besa.automatic.agency/snapp-market/product/%d9%85%d8%a7%db%8c%d8%b9-%d8%af%d8%b3%d8%aa%d8%b4%d9%88%db%8c%db%8c-%da%a9%d8%b1%d9%85%db%8c-%d8%b2%d8%b1%d8%af-%d8%a7%d9%88%d9%87-%db%b2-%da%af%d8%b1%d9%85%db%8c/" class="product-image">
		<img width="280" height="280" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/114012991-280x280.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy" />	</a>
</div>
            
                
<div class="product-item">
	<a title="حشره کش چند منظوره اتک ۵۰۰ میلی لیتری" href="http://besa.automatic.agency/snapp-market/product/%d8%ad%d8%b4%d8%b1%d9%87-%da%a9%d8%b4-%da%86%d9%86%d8%af-%d9%85%d9%86%d8%b8%d9%88%d8%b1%d9%87-%d8%a7%d8%aa%da%a9-%db%b5%db%b0%db%b0-%d9%85%db%8c%d9%84%db%8c-%d9%84%db%8c%d8%aa%d8%b1%db%8c/" class="product-image">
		<img width="280" height="280" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/12108384-4328-48380121-1-280x280.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy" />	</a>
</div>
            
                
<div class="product-item">
	<a title="لوله بازکن صاف ۱.۲۵ کیلوگرمی" href="http://besa.automatic.agency/snapp-market/product/%d9%84%d9%88%d9%84%d9%87-%d8%a8%d8%a7%d8%b2%da%a9%d9%86-%d8%b5%d8%a7%d9%81-%db%b1-%db%b2%db%b5-%da%a9%db%8c%d9%84%d9%88%da%af%d8%b1%d9%85%db%8c/" class="product-image">
		<img width="280" height="280" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/5d3c1f3bd01ec-280x280.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy" />	</a>
</div>
            
                
<div class="product-item">
	<a title="خورش قیمه سیب زمینی هانی ۲۸۵ گرمی" href="http://besa.automatic.agency/snapp-market/product/%d8%ae%d9%88%d8%b1%d8%b4-%d9%82%db%8c%d9%85%d9%87-%d8%b3%db%8c%d8%a8-%d8%b2%d9%85%db%8c%d9%86%db%8c-%d9%87%d8%a7%d9%86%db%8c-%db%b2%db%b8%db%b5-%da%af%d8%b1%d9%85%db%8c/" class="product-image">
		<img width="280" height="280" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/hph-71377-a-280x280.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy" />	</a>
</div>            </div>

                        <a class="btn-readmore" href="http://besa.automatic.agency/snapp-market/برگه-نمونه/" title="">مشاهده تمامی محصولات</a>
                </div>

            
    
	    

</div>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
						</div>
						</div>
					</div>
		 

		<div id="nav-cover"></div>
</header>
	<div id="tbay-main-content">
<section id="main-container" class=" container inner">
	<div id="main-content" class="main-page page-404">

		<section class="error-404 text-center">
			<h1>اوه!</h1>
			<h3>خطای 404: برگه یافت نشد</h3>
			<div class="page-content">
				<p class="sub-title">ما متاسفبم! گویا این صفحه حذف شده است! برگردید  <a class="backtohome" href="http://besa.automatic.agency/snapp-market/">صفحه اصلی</a>
				در صورتیکه اشتباه است.</span></p>
			</div><!-- .page-content -->
		</section><!-- .error-404 -->
	</div>
</section>


	</div><!-- .site-content -->
		
	<footer id="tbay-footer" class="tbay-footer snappmarket-footer">
					
					<div data-elementor-type="wp-post" data-elementor-id="165" class="elementor elementor-165" data-elementor-settings="[]">
						<div class="elementor-inner">
							<div class="elementor-section-wrap">
							<section class="elementor-section elementor-top-section elementor-element elementor-element-24b00419 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="24b00419" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-narrow">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-14 elementor-top-column elementor-element elementor-element-41ffa8d0" data-id="41ffa8d0" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-3ca5454e elementor-widget elementor-widget-heading" data-id="3ca5454e" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<div class="elementor-heading-title elementor-size-default">دانلود اپلیکیشن</div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-14 elementor-top-column elementor-element elementor-element-66e3c4b6" data-id="66e3c4b6" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-4a31a560 elementor-widget elementor-widget-image" data-id="4a31a560" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="563" height="167" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/cafe-bazaar.a965c1e6.png" class="attachment-large size-large" alt="" loading="lazy" />											</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-14 elementor-top-column elementor-element elementor-element-75ca71d0" data-id="75ca71d0" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-4fac5393 elementor-widget elementor-widget-image" data-id="4fac5393" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="206" height="66" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/download-1.png" class="attachment-large size-large" alt="" loading="lazy" />											</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-14 elementor-top-column elementor-element elementor-element-66f7d9ca" data-id="66f7d9ca" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-78e4494d elementor-widget elementor-widget-image" data-id="78e4494d" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="206" height="66" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/download.png" class="attachment-large size-large" alt="" loading="lazy" />											</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-14 elementor-top-column elementor-element elementor-element-4bdff868" data-id="4bdff868" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-6834a63e elementor-widget elementor-widget-image" data-id="6834a63e" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="563" height="167" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/cafe-bazaar.a965c1e6.png" class="attachment-large size-large" alt="" loading="lazy" />											</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-14 elementor-top-column elementor-element elementor-element-85c6882" data-id="85c6882" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-5f5e7382 elementor-widget elementor-widget-heading" data-id="5f5e7382" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<div class="elementor-heading-title elementor-size-default">ما را دنبال کنید
</div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-14 elementor-top-column elementor-element elementor-element-231e6b13" data-id="231e6b13" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-881dd88 elementor-shape-circle elementor-grid-0 elementor-widget elementor-widget-social-icons" data-id="881dd88" data-element_type="widget" data-widget_type="social-icons.default">
				<div class="elementor-widget-container">
					<div class="elementor-social-icons-wrapper elementor-grid">
							<div class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-repeater-item-b1e00db" target="_blank">
						<span class="elementor-screen-only">Facebook</span>
						<i class="fab fa-facebook"></i>					</a>
				</div>
							<div class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-repeater-item-1318686" target="_blank">
						<span class="elementor-screen-only">Twitter</span>
						<i class="fab fa-twitter"></i>					</a>
				</div>
							<div class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-youtube elementor-repeater-item-a058f20" target="_blank">
						<span class="elementor-screen-only">Youtube</span>
						<i class="fab fa-youtube"></i>					</a>
				</div>
					</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-15056208 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="15056208" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-narrow">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-edde1b0" data-id="edde1b0" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-258271e0 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="258271e0" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
										<span class="elementor-icon-list-text">تماس با ما</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="icon- icon-location-pin"></i>						</span>
										<span class="elementor-icon-list-text">آدرس: تهران، جردن، بالاتر از اسفندیار، خیابان سعیدی، نبش تقاطع خیابان مهرداد، پلاک ۳۳، طبقه ۳، واحد ۹</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="zmdi zmdi-phone"></i>						</span>
										<span class="elementor-icon-list-text">تلفن: ۰۲۱۹۶۶۱۲۶۰۰</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="zmdi zmdi-email"></i>						</span>
										<span class="elementor-icon-list-text">ایمیل: info@snapp.market</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-barcode"></i>						</span>
										<span class="elementor-icon-list-text">کد پستی: ۱۹۶۷۸۶۵۶۳۱</span>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-5546295a" data-id="5546295a" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-4e1f1f51 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="4e1f1f51" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
					<a href="http://besa.automatic.agency/snapp-market/aboutus/">					<span class="elementor-icon-list-text">درباره ما</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
					<a href="http://besa.automatic.agency/snapp-market/faqs/">					<span class="elementor-icon-list-text">قوانین و مقررات</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
					<a href="http://besa.automatic.agency/snapp-market/dashboard/">					<span class="elementor-icon-list-text">پیشخوان فروشنده</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
					<a href="http://besa.automatic.agency/snapp-market/privacy/">					<span class="elementor-icon-list-text">ثبت شکایات</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
					<a href="http://besa.automatic.agency/snapp-market/product/%d8%a2%d8%b1%d8%af-%d8%b3%d9%81%db%8c%d8%af-%d8%b1%d8%b4%d8%af-%db%b4%db%b5%db%b0-%da%af%d8%b1%d9%85%db%8c/">					<span class="elementor-icon-list-text">تک محصول</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
					<a href="http://besa.automatic.agency/snapp-market/shop/">					<span class="elementor-icon-list-text">لیست محصولات</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-35981fc" data-id="35981fc" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-fe1a826 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="fe1a826" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-f460e7f" data-id="f460e7f" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-95aea77 elementor-widget elementor-widget-image" data-id="95aea77" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="150" height="150" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/logo-1.png" class="attachment-large size-large" alt="" loading="lazy" />											</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-35ca66ad" data-id="35ca66ad" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-2ee7d66e elementor-widget elementor-widget-image" data-id="2ee7d66e" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="125" height="136" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/logo.png" class="attachment-large size-large" alt="" loading="lazy" />											</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-2d6d29d7" data-id="2d6d29d7" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-25ad311 elementor-widget elementor-widget-image" data-id="25ad311" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="168" height="222" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/1e5dab5a.png" class="attachment-large size-large" alt="" loading="lazy" />											</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-28b4af24 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="28b4af24" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-narrow">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-826a8c1" data-id="826a8c1" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-129d4095 elementor-widget elementor-widget-image" data-id="129d4095" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="660" height="320" src="http://besa.automatic.agency/snapp-market/wp-content/uploads/2020/06/besamarket-logo.png" class="attachment-large size-large" alt="" loading="lazy" />											</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-3ff51224" data-id="3ff51224" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-30fed429 elementor-widget elementor-widget-text-editor" data-id="30fed429" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"><p>اسنپ مارکت، حاصل همکاری دو شرکت بزرگ «اسنپ» و «هایپراستار» است و عضو جدید خانواده‌ی بزرگ اسنپ محسوب می‌شود. کاربران اسنپ مارکت می‌توانند کالاهای سوپرمارکتی موردنیاز خود را با بهره‌مندی از تخفیف‌های هایپراستار انجام دهند. تمامی کالاهای خریداری‌شده‌ی کاربران را هایپراستار تأمین خواهد کرد و با پشتیبانی بزرگ‌ترین سرویس حمل‌ونقل آنلاین ایران، اسنپ، در زمان انتخابی کاربران به دست آن‌ها خواهد رسید.</p></div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
						</div>
						</div>
					</div>
		
					
	</footer><!-- .site-footer -->
	
	
			<div class="tbay-to-top">
			<a href="javascript:void(0);" id="back-to-top">
				<i class="tb-icon tb-icon-chevron-up"></i>
			</a>
		</div>
	
			<div class="tbay-to-top-mobile tbay-to-top">

			<div class="more-to-top">
			
				<a href="javascript:void(0);" id="back-to-top-mobile">
					<i class="tb-icon tb-icon-chevron-up"></i>
				</a>
				
			</div>
		</div>
		
		
		
	

</div><!-- .site -->

	<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})()
	</script>
	<link rel='stylesheet' id='sumoselect-css'  href='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/css/sumoselect.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-165-css'  href='http://besa.automatic.agency/snapp-market/wp-content/uploads/elementor/css/post-165.css?ver=1605910088' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='http://besa.automatic.agency/snapp-market/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.0.13' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-108-css'  href='http://besa.automatic.agency/snapp-market/wp-content/uploads/elementor/css/post-108.css?ver=1605910088' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=5.5.3' type='text/css' media='all' />
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/jquery.validate.js?ver=1.0' id='jquery-validate-js'></script>
<script type='text/javascript' id='besa-auth-script-js-extra'>
/* <![CDATA[ */
var besa_ajax_auth_object = {"ajaxurl":"http:\/\/besa.automatic.agency\/snapp-market\/wp-admin\/admin-ajax.php","redirecturl":"http:\/\/besa.automatic.agency\/snapp-market","loadingmessage":"\u062f\u0631 \u062d\u0627\u0644 \u0627\u0631\u0633\u0627\u0644 \u0627\u0637\u0644\u0627\u0639\u0627\u062a \u06a9\u0627\u0631\u0628\u0631\u060c \u0645\u0646\u062a\u0638\u0631 \u0628\u0645\u0627\u0646\u06cc\u062f ...","validate":{"required":"\u0627\u06cc\u0646 \u0641\u06cc\u0644\u062f \u0627\u0644\u0632\u0627\u0645\u06cc \u0627\u0633\u062a.","remote":"\u0627\u06cc\u0646 \u0641\u06cc\u0644\u062f \u0631\u0627 \u0641\u06cc\u06a9\u0633 \u06a9\u0646\u06cc\u062f.","email":"\u0622\u062f\u0631\u0633 \u0627\u06cc\u0645\u06cc\u0644 \u0645\u0639\u062a\u0628\u0631 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","url":"\u06cc\u06a9 \u0622\u062f\u0631\u0633 \u0645\u0639\u062a\u0628\u0631 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","date":"\u062a\u0627\u0631\u06cc\u062e \u0645\u0639\u062a\u0628\u0631\u06cc \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","dateISO":"\u062a\u0627\u0631\u06cc\u062e \u0645\u0639\u062a\u0628\u0631\u06cc (ISO) \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","number":"\u06cc\u06a9 \u0634\u0645\u0627\u0631\u0647 \u0645\u0639\u062a\u0628\u0631 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","digits":"\u0641\u0642\u0637 \u0639\u062f\u062f \u0648 \u0631\u0642\u0645 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","creditcard":"\u06cc\u06a9 \u0634\u0645\u0627\u0631\u0647 \u06a9\u0627\u0631\u062a \u0645\u0639\u062a\u0628\u0631 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","equalTo":"\u0645\u0642\u062f\u0627\u0631 \u06cc\u06a9\u0633\u0627\u0646\u06cc \u0631\u0627 \u0645\u062c\u062f\u062f\u0627 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","accept":"\u06cc\u06a9 \u0645\u0642\u062f\u0627\u0631 \u0628\u0627 \u067e\u0633\u0648\u0646\u062f \u0641\u0627\u06cc\u0644 \u0645\u0639\u062a\u0628\u0631 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","maxlength":"\u0628\u06cc\u0634\u062a\u0631 \u0627\u0632 {0} \u06a9\u0627\u0631\u06a9\u062a\u0631 \u0648\u0627\u0631\u062f \u0646\u06a9\u0646\u06cc\u062f.","minlength":"\u062d\u062f\u0627\u0642\u0644 {0} \u06a9\u0627\u0631\u06a9\u062a\u0631 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","rangelength":"\u0645\u0642\u062f\u0627\u0631\u06cc \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f \u06a9\u0647 \u0628\u06cc\u0646 {0} \u0648 {1} \u0637\u0648\u0644 \u062a\u0639\u062f\u0627\u062f \u06a9\u0627\u0631\u06a9\u062a\u0631\u0647\u0627\u06cc \u0622\u0646 \u0628\u0627\u0634\u062f.","range":"\u0645\u0642\u062f\u0627\u0631\u06cc \u0628\u06cc\u0646 {0} \u0648 {1} \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","max":"\u0645\u0642\u062f\u0627\u0631\u06cc \u06a9\u0648\u0686\u06a9\u062a\u0631 \u0645\u0633\u0627\u0648\u06cc {0} \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.","min":"\u0645\u0642\u062f\u0627\u0631\u06cc \u0628\u0632\u0631\u06af\u062a\u0631 \u0645\u0633\u0627\u0648\u06cc {0} \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f."}};
/* ]]> */
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/ajax-auth-script.js?ver=1.0' id='besa-auth-script-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.selectBox.min.js?ver=1.2.0' id='jquery-selectBox-js'></script>
<script type='text/javascript' id='jquery-yith-wcwl-js-extra'>
/* <![CDATA[ */
var yith_wcwl_l10n = {"ajax_url":"\/snapp-market\/wp-admin\/admin-ajax.php","redirect_to_cart":"no","multi_wishlist":"","hide_add_button":"1","enable_ajax_loading":"","ajax_loader_url":"http:\/\/besa.automatic.agency\/snapp-market\/wp-content\/plugins\/yith-woocommerce-wishlist\/assets\/images\/ajax-loader-alt.svg","remove_from_wishlist_after_add_to_cart":"1","is_wishlist_responsive":"1","time_to_close_prettyphoto":"3000","fragments_index_glue":".","reload_on_found_variation":"1","labels":{"cookie_disabled":"We are sorry, but this feature is available only if cookies on your browser are enabled.","added_to_cart_message":"<div class=\"woocommerce-notices-wrapper\"><div class=\"woocommerce-message\" role=\"alert\">Product added to cart successfully<\/div><\/div>"},"actions":{"add_to_wishlist_action":"add_to_wishlist","remove_from_wishlist_action":"remove_from_wishlist","reload_wishlist_and_adding_elem_action":"reload_wishlist_and_adding_elem","load_mobile_action":"load_mobile","delete_item_action":"delete_item","save_title_action":"save_title","save_privacy_action":"save_privacy","load_fragments":"load_fragments"}};
/* ]]> */
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.yith-wcwl.js?ver=3.0.16' id='jquery-yith-wcwl-js'></script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/besa.automatic.agency\/snapp-market\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.3' id='contact-form-7-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/snapp-market\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/snapp-market\/?wc-ajax=%%endpoint%%","i18n_view_cart":"\u0645\u0634\u0627\u0647\u062f\u0647 \u0633\u0628\u062f \u062e\u0631\u06cc\u062f","cart_url":"http:\/\/besa.automatic.agency\/snapp-market\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=4.7.0' id='wc-add-to-cart-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/snapp-market\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/snapp-market\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=4.7.0' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/snapp-market\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/snapp-market\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_72a203cd4931b513a4ac60b1653253b6","fragment_name":"wc_fragments_72a203cd4931b513a4ac60b1653253b6","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=4.7.0' id='wc-cart-fragments-js'></script>
<script type='text/javascript' defer src='//besa.automatic.agency/snapp-market/wp-content/plugins/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.min.js?ver=3.1.6' id='prettyPhoto-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/dokan-lite/assets/vendors/magnific/jquery.magnific-popup.min.js?ver=3.0.14' id='dokan-popup-js'></script>
<script type='text/javascript' id='dokan-i18n-jed-js-extra'>
/* <![CDATA[ */
var dokan = {"ajaxurl":"http:\/\/besa.automatic.agency\/snapp-market\/wp-admin\/admin-ajax.php","nonce":"a94923d499","ajax_loader":"http:\/\/besa.automatic.agency\/snapp-market\/wp-content\/plugins\/dokan-lite\/assets\/images\/ajax-loader.gif","seller":{"available":"\u062f\u0631 \u062f\u0633\u062a\u0631\u0633","notAvailable":"\u0645\u0648\u062c\u0648\u062f \u0646\u06cc\u0633\u062a."},"delete_confirm":"\u0634\u0645\u0627 \u0645\u0637\u0645\u0626\u0646 \u0647\u0633\u062a\u06cc\u062f\u061f","wrong_message":"\u0638\u0627\u0647\u0631\u0627\u064b \u0627\u0634\u062a\u0628\u0627\u0647\u06cc \u0635\u0648\u0631\u062a \u06af\u0631\u0641\u062a\u0647 \u0627\u0633\u062a. \u0644\u0637\u0641\u0627 \u062f\u0648\u0628\u0627\u0631\u0647 \u062a\u0644\u0627\u0634 \u06a9\u0646\u06cc\u062f.","vendor_percentage":"100","commission_type":"percentage","rounding_precision":"6","mon_decimal_point":".","product_types":["simple"],"rest":{"root":"http:\/\/besa.automatic.agency\/snapp-market\/wp-json\/","nonce":"38bf279e6d","version":"dokan\/v1"},"api":null,"libs":[],"routeComponents":{"default":null},"routes":[],"urls":{"assetsUrl":"http:\/\/besa.automatic.agency\/snapp-market\/wp-content\/plugins\/dokan-lite\/assets"}};
/* ]]> */
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/dokan-lite/assets/vendors/i18n/jed.js?ver=3.0.14' id='dokan-i18n-jed-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/dokan-lite/assets/js/login-form-popup.js?ver=1605901585' id='dokan-login-form-popup-js'></script>
<script type='text/javascript' id='besa-script-js-extra'>
/* <![CDATA[ */
var besa_settings = {"quantity_minus":"<i class=\"tb-icon tb-icon-minus\"><\/i>","quantity_plus":"<i class=\"tb-icon tb-icon-plus\"><\/i>","cancel":"\u0644\u063a\u0648","show_all_text":"\u0645\u0634\u0627\u0647\u062f\u0647 \u0647\u0645\u0647","search":"\u062c\u0633\u062a\u062c\u0648","posts":"{\"page\":0,\"pagename\":\"popper-js\",\"error\":\"\",\"m\":\"\",\"p\":0,\"post_parent\":\"\",\"subpost\":\"\",\"subpost_id\":\"\",\"attachment\":\"\",\"attachment_id\":0,\"name\":\"popper-js\",\"page_id\":0,\"second\":\"\",\"minute\":\"\",\"hour\":\"\",\"day\":0,\"monthnum\":0,\"year\":0,\"w\":0,\"category_name\":\"\",\"tag\":\"\",\"cat\":\"\",\"tag_id\":\"\",\"author\":\"\",\"author_name\":\"\",\"feed\":\"\",\"tb\":\"\",\"paged\":0,\"meta_key\":\"\",\"meta_value\":\"\",\"preview\":\"\",\"s\":\"\",\"sentence\":\"\",\"title\":\"\",\"fields\":\"\",\"menu_order\":\"\",\"embed\":\"\",\"category__in\":[],\"category__not_in\":[],\"category__and\":[],\"post__in\":[],\"post__not_in\":[],\"post_name__in\":[],\"tag__in\":[],\"tag__not_in\":[],\"tag__and\":[],\"tag_slug__in\":[],\"tag_slug__and\":[],\"post_parent__in\":[],\"post_parent__not_in\":[],\"author__in\":[],\"author__not_in\":[],\"ignore_sticky_posts\":false,\"suppress_filters\":false,\"cache_results\":true,\"update_post_term_cache\":true,\"lazy_load_term_meta\":true,\"update_post_meta_cache\":true,\"post_type\":\"\",\"posts_per_page\":10,\"nopaging\":false,\"comments_per_page\":\"50\",\"no_found_rows\":false,\"order\":\"DESC\"}","max_page":"0","mobile":"","timeago":{"suffixAgo":"\u067e\u06cc\u0634","suffixFromNow":"\u0627\u0632 \u0627\u0644\u0627\u0646","inPast":"\u0686\u0646\u062f \u0644\u062d\u0638\u0647 \u067e\u06cc\u0634 \u062a\u0627 \u0627\u0644\u0627\u0646","seconds":"\u06a9\u0645\u062a\u0631 \u0627\u0632 \u06cc\u06a9 \u062f\u0642\u06cc\u0642\u0647","minute":"\u062d\u062f\u0648\u062f \u06cc\u06a9 \u062f\u0642\u06cc\u0642\u0647","minutes":"%d \u062f\u0642\u06cc\u0642\u0647","hour":"\u062d\u062f\u0648\u062f \u06cc\u06a9 \u0633\u0627\u0639\u062a","hours":"\u062d\u062f\u0648\u062f %d \u0633\u0627\u0639\u062a","day":"\u06cc\u06a9 \u0631\u0648\u0632","days":"%d \u0631\u0648\u0632","month":"\u062d\u062f\u0648\u062f \u06cc\u06a9 \u0645\u0627\u0647","months":"%d \u0645\u0627\u0647","year":"\u062d\u062f\u0648\u062f \u06cc\u06a9 \u0633\u0627\u0644","years":"%d \u0633\u0627\u0644"},"elements_ready":{"slick":["brands","products","posts-grid","our-team","instagram","product-category","product-tabs","testimonials","product-categories-tabs","list-categories-product","custom-image-list-categories","custom-image-list-tags","product-recently-viewed","product-flash-sales","product-list-tags","product-count-down"],"countdowntimer":["product-flash-sales","product-count-down"]},"current_page":"1","popup_cart_icon":"<i class=\"tb-icon tb-icon-cross\"><\/i>","popup_cart_noti":"\u0628\u0647 \u0633\u0628\u062f \u062e\u0631\u06cc\u062f \u0627\u0641\u0632\u0648\u062f\u0647 \u0634\u062f.","cart_position":"popup","ajax_update_quantity":"1","display_mode":"grid","ajaxurl":"http:\/\/besa.automatic.agency\/snapp-market\/wp-admin\/admin-ajax.php","loader":"http:\/\/besa.automatic.agency\/snapp-market\/wp-content\/themes\/besa\/images\/ajax-loader.gif","is_checkout":"","checkout_url":"http:\/\/besa.automatic.agency\/snapp-market\/checkout\/","i18n_checkout":"\u062a\u0633\u0648\u06cc\u0647 \u062d\u0633\u0627\u0628","img_class_container":".woocommerce-product-gallery__image","thumbnail_gallery_class_element":".flex-control-nav.flex-control-thumbs li"};
/* ]]> */
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/functions.min.js?ver=1.0' id='besa-script-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/woocommerce.min.js?ver=1.0' id='besa-woocommerce-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/skip-link-fix.min.js?ver=1.0' id='besa-skip-link-fix-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/popper.min.js?ver=1.12.9' id='popper-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/bootstrap.min.js?ver=4.0.0' id='bootstrap-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/jquery.autocomplete.min.js?ver=1.0.0' id='jquery-autocomplete-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/detectmobilebrowser.min.js?ver=1.0.6' id='detectmobilebrowser-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/jquery.fastclick.min.js?ver=1.0.6' id='jquery-fastclick-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-includes/js/underscore.min.js?ver=1.8.3' id='underscore-js'></script>
<script type='text/javascript' id='wp-util-js-extra'>
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/snapp-market\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-includes/js/wp-util.min.js?ver=5.5.3' id='wp-util-js'></script>
<script type='text/javascript' id='wc-add-to-cart-variation-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_variation_params = {"wc_ajax_url":"\/snapp-market\/?wc-ajax=%%endpoint%%","i18n_no_matching_variations_text":"\u0628\u0627 \u0639\u0631\u0636 \u067e\u0648\u0632\u0634\u060c \u0647\u06cc\u0686 \u0643\u0627\u0644\u0627\u064a\u06cc \u0645\u0637\u0627\u0628\u0642 \u0627\u0646\u062a\u062e\u0627\u0628 \u0634\u0645\u0627 \u06cc\u0627\u0641\u062a \u0646\u0634\u062f. \u0644\u0637\u0641\u0627\u064b \u062a\u0631\u06a9\u06cc\u0628 \u062f\u06cc\u06af\u0631\u06cc \u0631\u0627 \u0627\u0646\u062a\u062e\u0627\u0628 \u06a9\u0646\u06cc\u062f.","i18n_make_a_selection_text":"\u0644\u0637\u0641\u0627 \u0628\u0631\u062e\u06cc \u0627\u0632 \u06af\u0632\u06cc\u0646\u0647\u200c\u0647\u0627\u06cc \u0645\u062d\u0635\u0648\u0644 \u0631\u0627 \u0642\u0628\u0644 \u0627\u0632 \u0627\u0636\u0627\u0641\u0647 \u06a9\u0631\u062f\u0646 \u0622\u0646 \u0628\u0647 \u0633\u0628\u062f \u062e\u0631\u06cc\u062f\u060c \u0627\u0646\u062a\u062e\u0627\u0628 \u06a9\u0646\u06cc\u062f.","i18n_unavailable_text":"\u0628\u0627 \u0639\u0631\u0636 \u067e\u0648\u0632\u0634\u060c \u0627\u06cc\u0646 \u0643\u0627\u0644\u0627 \u062f\u0631 \u062f\u0633\u062a\u0631\u0633 \u0646\u06cc\u0633\u062a. \u0644\u0637\u0641\u0627\u064b \u062a\u0631\u06a9\u06cc\u0628 \u062f\u06cc\u06af\u0631\u06cc \u0631\u0627 \u0627\u0646\u062a\u062e\u0627\u0628 \u06a9\u0646\u06cc\u062f."};
/* ]]> */
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart-variation.min.js?ver=4.7.0' id='wc-add-to-cart-variation-js'></script>
<script type='text/javascript' id='wc-single-product-js-extra'>
/* <![CDATA[ */
var wc_single_product_params = {"i18n_required_rating_text":"\u0644\u0637\u0641\u0627 \u06cc\u06a9 \u0627\u0645\u062a\u06cc\u0627\u0632 \u0631\u0627 \u0627\u0646\u062a\u062e\u0627\u0628 \u06a9\u0646\u06cc\u062f","review_rating_required":"yes","flexslider":{"rtl":true,"animation":"slide","smoothHeight":true,"directionNav":false,"controlNav":"thumbnails","slideshow":false,"animationSpeed":500,"animationLoop":false,"allowOneSlide":false},"zoom_enabled":"1","zoom_options":[],"photoswipe_enabled":"1","photoswipe_options":{"shareEl":false,"closeOnScroll":false,"history":false,"hideAnimationDuration":0,"showAnimationDuration":0},"flexslider_enabled":"1"};
/* ]]> */
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/woocommerce/assets/js/frontend/single-product.min.js?ver=4.7.0' id='wc-single-product-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-includes/js/wp-embed.min.js?ver=5.5.3' id='wp-embed-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/jquery.mmenu.min.js?ver=7.0.5' id='jquery-mmenu-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/jquery.sumoselect.min.js?ver=3.0.2' id='jquery-sumoselect-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/jquery.treeview.min.js?ver=1.4.0' id='jquery-treeview-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/slick.min.js?ver=1.0.0' id='slick-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/themes/besa/js/custom-slick.min.js?ver=1.0' id='besa-custom-slick-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.0.13' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-includes/js/jquery/ui/position.min.js?ver=1.11.4' id='jquery-ui-position-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.8.1' id='elementor-dialog-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6' id='swiper-js'></script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=3.0.13' id='share-link-js'></script>
<script type='text/javascript' id='elementor-frontend-js-before'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false},"i18n":{"shareOnFacebook":"\u0627\u0634\u062a\u0631\u0627\u06a9\u200c\u06af\u0630\u0627\u0631\u06cc \u0631\u0648\u06cc \u0641\u06cc\u0633\u200c\u0628\u0648\u06a9","shareOnTwitter":"\u0627\u0634\u062a\u0631\u0627\u06a9\u200c\u06af\u0630\u0627\u0631\u06cc \u0631\u0648\u06cc \u062a\u0648\u06cc\u06cc\u062a\u0631","pinIt":"\u0633\u0646\u062c\u0627\u0642 \u06a9\u0646","download":"\u062f\u0631\u06cc\u0627\u0641\u062a","downloadImage":"\u062f\u0627\u0646\u0644\u0648\u062f \u062a\u0635\u0648\u06cc\u0631","fullscreen":"\u062a\u0645\u0627\u0645 \u0635\u0641\u062d\u0647","zoom":"\u0628\u0632\u0631\u06af\u0646\u0645\u0627\u06cc\u06cc","share":"\u0627\u0634\u062a\u0631\u0627\u06a9\u200c\u06af\u0630\u0627\u0631\u06cc","playVideo":"\u067e\u062e\u0634 \u0648\u06cc\u062f\u06cc\u0648","previous":"\u0642\u0628\u0644\u06cc","next":"\u0628\u0639\u062f\u06cc","close":"\u0628\u0633\u062a\u0646"},"is_rtl":true,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1200,"xl":1440,"xxl":1600},"version":"3.0.13","is_static":false,"legacyMode":{"elementWrappers":true},"urls":{"assets":"http:\/\/besa.automatic.agency\/snapp-market\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":0,"title":"\u0628\u0631\u06af\u0647 \u067e\u06cc\u062f\u0627 \u0646\u0634\u062f &#8211; \u0642\u0627\u0644\u0628 \u0628\u0633\u0627\u0645\u0627\u0631\u06a9\u062a | \u062f\u0645\u0648\u06cc \u0627\u062e\u062a\u0635\u0627\u0635\u06cc \u0627\u0633\u0646\u067e \u0645\u0627\u0631\u06a9\u062a","excerpt":""}};
</script>
<script type='text/javascript' defer src='http://besa.automatic.agency/snapp-market/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.0.13' id='elementor-frontend-js'></script>
		    <div id="tbay-cart-modal" tabindex="-1" role="dialog" aria-hidden="true">
		        <div class="modal-dialog modal-lg">
		            <div class="modal-content">
		                <div class="modal-body">
		                    <div class="modal-body-content"></div>
		                </div>
		            </div>
		        </div>
		    </div>
		    
</body>
</html>
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.boldgrid.com/w3-total-cache/


Served from: besa.automatic.agency @ 1399-10-02 15:14:16 by W3 Total Cache
-->